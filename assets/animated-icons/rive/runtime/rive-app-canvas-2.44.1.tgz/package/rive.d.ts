import * as rc from "./rive_advanced.mjs";
import { RuntimeLoader, type RuntimeCallback } from "./runtimeLoader";
import { SemanticTreeModel, AccessibilityOverlay, SemanticMode, type RiveSemanticsOptions } from "./semantics";
import { ImageWrapper, AudioWrapper, FontWrapper, RiveFont as RiveFontClassUtil } from "./utils";
export type AssetLoadCallback = (asset: rc.FileAsset, bytes: Uint8Array) => boolean;
export { RiveFontClassUtil as RiveFont };
export { SemanticMode };
export type { RiveSemanticsOptions };
export type { FileAsset, AudioAsset, FontAsset, ImageAsset, } from "./rive_advanced.mjs";
/**
 * Generic type for a parameterless void callback
 */
export type VoidCallback = () => void;
interface SetupRiveListenersOptions {
    isTouchScrollEnabled?: boolean;
}
/**
 * Type for artboard bounds
 */
export type Bounds = rc.AABB;
export declare enum Fit {
    Cover = "cover",
    Contain = "contain",
    Fill = "fill",
    FitWidth = "fitWidth",
    FitHeight = "fitHeight",
    None = "none",
    ScaleDown = "scaleDown",
    Layout = "layout"
}
export declare enum Alignment {
    Center = "center",
    TopLeft = "topLeft",
    TopCenter = "topCenter",
    TopRight = "topRight",
    CenterLeft = "centerLeft",
    CenterRight = "centerRight",
    BottomLeft = "bottomLeft",
    BottomCenter = "bottomCenter",
    BottomRight = "bottomRight"
}
export declare enum DrawOptimizationOptions {
    AlwaysDraw = "alwaysDraw",
    DrawOnChanged = "drawOnChanged"
}
export interface RiveFocusOptions {
    /**
     * When true, allows Rive to interrupt browser focus and programmatically
     * set/release focus on the canvas when the state machine reports focus
     * changes in Rive. This allows apps to direct focus to/from the canvas or
     * related elements as needed if not currently focused, which can happen at
     * any point in the Rive render loop.
     *
     * Note: Nodes in the Rive graphic may still receive/release focus respecting
     * any focus rules defined in the state machine.
     *
     * @default false to prevent unwanted focus interruptions
     */
    allowFocusInterrupt: boolean;
}
export interface LayoutParameters {
    fit?: Fit;
    alignment?: Alignment;
    layoutScaleFactor?: number;
    minX?: number;
    minY?: number;
    maxX?: number;
    maxY?: number;
}
export declare class Layout {
    private cachedRuntimeFit;
    private cachedRuntimeAlignment;
    readonly fit: Fit;
    readonly alignment: Alignment;
    readonly layoutScaleFactor: number;
    readonly minX: number;
    readonly minY: number;
    readonly maxX: number;
    readonly maxY: number;
    constructor(params?: LayoutParameters);
    static new({ fit, alignment, minX, minY, maxX, maxY, }: LayoutParameters): Layout;
    /**
     * Makes a copy of the layout, replacing any specified parameters
     */
    copyWith({ fit, alignment, layoutScaleFactor, minX, minY, maxX, maxY, }: LayoutParameters): Layout;
    runtimeFit(rive: rc.RiveCanvas): rc.Fit;
    runtimeAlignment(rive: rc.RiveCanvas): rc.Alignment;
}
export { RuntimeLoader, type RuntimeCallback };
/**
 * @deprecated State machine inputs are deprecated and will be removed in a
 * future major version: please use data binding properties instead. See
 * {@link https://rive.app/docs/editor/data-binding/migration-guide#state-machine-inputs}
 * for how to migrate.
 */
export declare enum StateMachineInputType {
    Number = 56,
    Trigger = 58,
    Boolean = 59
}
/**
 * An input for a state machine
 * @deprecated State machine inputs are deprecated and will be removed in a
 * future major version: please use data binding properties instead. See
 * {@link https://rive.app/docs/editor/data-binding/migration-guide#state-machine-inputs}
 * for how to migrate.
 */
export declare class StateMachineInput {
    readonly type: StateMachineInputType;
    private runtimeInput;
    constructor(type: StateMachineInputType, runtimeInput: rc.SMIInput);
    /**
     * Returns the name of the input
     */
    get name(): string;
    /**
     * Returns the current value of the input
     */
    get value(): number | boolean;
    /**
     * Sets the value of the input
     */
    set value(value: number | boolean);
    /**
     * Fires a trigger; does nothing on Number or Boolean input types
     */
    fire(): void;
    /**
     * Deletes the input
     */
    delete(): void;
}
/**
 * @deprecated Subscribing to Rive Events at runtime is deprecated and will be removed in a future major
 * version: please use data binding instead. See
 * {@link https://rive.app/docs/runtimes/web/rive-events} for how to migrate.
 */
export declare enum RiveEventType {
    General = 128,
    OpenUrl = 131
}
declare class BaseArtboard {
    isBindableArtboard: boolean;
    constructor(_isBindableArtboard: boolean);
}
declare class Artboard extends BaseArtboard {
    nativeArtboard: rc.Artboard;
    file: RiveFile;
    constructor(artboard: rc.Artboard, _file: RiveFile);
}
declare class BindableArtboard extends BaseArtboard implements rc.FinalizableTarget {
    selfUnref: boolean;
    nativeArtboard: rc.BindableArtboard;
    nativeViewModel: rc.ViewModelInstance | null;
    constructor(artboard: rc.BindableArtboard);
    set viewModel(value: ViewModelInstance);
    destroy(): void;
}
/**
 * Supported event types triggered in Rive
 */
export declare enum EventType {
    Load = "load",
    LoadError = "loaderror",
    Play = "play",
    Pause = "pause",
    Stop = "stop",
    /**
     * @deprecated Loop events are deprecated and will be removed in a future
     * major version: they are only reported for linear animation playback, which
     * is deprecated. Use a state machine to control playback and data binding to
     * react to changes instead. See
     * {@link https://rive.app/docs/editor/data-binding/migration-guide} for how
     * to migrate.
     */
    Loop = "loop",
    Draw = "draw",
    Advance = "advance",
    /**
     * @deprecated Subscribing to state change events at runtime is deprecated
     * and will be removed in a future major version: use data binding (view model
     * property observers) or state machine actions to react to changes from your
     * graphic instead. See
     * {@link https://rive.app/docs/editor/state-machine/states#actions} for more details.
     */
    StateChange = "statechange",
    /**
     * @deprecated Subscribing to Rive Events at runtime is deprecated and will be removed in a future
     * major version: please use data binding instead. See
     * {@link https://rive.app/docs/runtimes/web/rive-events} for how to migrate.
     */
    RiveEvent = "riveevent",
    AudioStatusChange = "audiostatuschange"
}
/**
 * @deprecated Subscribing to Rive Events at runtime is deprecated and will be removed in a future major
 * version: please use data binding instead. See
 * {@link https://rive.app/docs/runtimes/web/rive-events} for how to migrate.
 */
export type RiveEventPayload = rc.RiveEvent | rc.OpenUrlEvent;
/**
 * The deprecations this runtime warns about. Each warning prints its own id, so
 * the value can be copied straight out of the console into
 * {@link Rive.suppressDeprecationWarnings}.
 */
export declare const DeprecationKeys: {
    readonly animationNames: "animation-names";
    readonly animationsParam: "animations-param";
    readonly defaultStateMachine: "default-state-machine";
    readonly legacyConstructors: "legacy-constructors";
    readonly legacyUnsubscribe: "legacy-unsubscribe";
    readonly loopEvents: "loop-events";
    readonly namesArray: "names-array";
    readonly riveEvents: "rive-events";
    readonly scrub: "scrub";
    readonly stateChangeEvents: "state-change-events";
    readonly stateMachineInputs: "state-machine-inputs";
    readonly stateMachinesParam: "state-machines-param";
    readonly textRuns: "text-runs";
};
/**
 * An id accepted by {@link Rive.suppressDeprecationWarnings}, as either a
 * {@link DeprecationKeys} entry or the string literal it holds.
 */
export type DeprecationId = (typeof DeprecationKeys)[keyof typeof DeprecationKeys];
export interface Event {
    type: EventType;
    data?: string | string[] | LoopEvent | number | RiveEventPayload | RiveFile;
}
/**
 * Looping types: one-shot, loop, and ping-pong
 * @deprecated Loop events are deprecated and will be removed in a future major
 * version: they are only reported for linear animation playback, which is
 * deprecated. Use a state machine to control playback and data binding to
 * react to changes instead.
 */
export declare enum LoopType {
    OneShot = "oneshot",// has value 0 in runtime
    Loop = "loop",// has value 1 in runtime
    PingPong = "pingpong"
}
/**
 * Loop events are returned through onloop callbacks
 * @deprecated Loop events are deprecated and will be removed in a future major
 * version: they are only reported for linear animation playback, which is
 * deprecated. Use a state machine to control playback and data binding to
 * react to changes instead.
 */
export interface LoopEvent {
    animation: string;
    type: LoopType;
}
/**
 * Loop events are returned through onloop callbacks
 */
export type EventCallback = (event: Event) => void;
/**
 * Event listeners registered with the event manager
 */
export interface EventListener {
    type: EventType;
    callback: EventCallback;
}
/**
 * FPS Reporting through callbacks sent to the WASM runtime
 */
export type FPSCallback = (fps: number) => void;
declare class EventManager {
    private listeners;
    constructor(listeners?: EventListener[]);
    private getListeners;
    add(listener: EventListener): void;
    /**
     * Removes a listener
     * @param listener the listener with the callback to be removed
     */
    remove(listener: EventListener): void;
    /**
     * Clears all listeners of specified type, or every listener if no type is
     * specified
     * @param type the type of listeners to clear, or all listeners if not
     * specified
     */
    removeAll(type?: EventType): void;
    fire(event: Event): void;
}
export interface Task {
    action?: VoidCallback;
    event?: Event;
}
declare class TaskQueueManager {
    private eventManager;
    private queue;
    constructor(eventManager: EventManager);
    add(task: Task): void;
    process(): void;
}
export interface RiveParameters {
    canvas: HTMLCanvasElement | OffscreenCanvas;
    /**
     * URI of the `.riv` file to load. Will be fetched by the runtime. Can be used instead of
     * `buffer` or `riveFile`.
     */
    src?: string;
    /**
     * ArrayBuffer of .riv file contents. Can be used instead of `src` or `riveFile` if you
     * fetch the file contents yourself.
     */
    buffer?: ArrayBuffer;
    /**
     * RiveFile instance if created separately. Useful if you reuse a Rive file across multiple instances.
     * Can be used instead of `src` or `buffer`.
     */
    riveFile?: RiveFile;
    /**
     * Name of the artboard to display.
     */
    artboard?: string;
    /**
     * Name of the state machine to play.
     */
    stateMachine?: string;
    /**
     * @deprecated Use the `stateMachine` parameter to play a state machine
     * instead. Support for starting playback with named animations will be
     * removed in a future major version.
     */
    animations?: string | string[];
    /**
     * @deprecated Use `stateMachine` with a single state machine name instead.
     * Support for playing multiple state machines at once will be removed in a
     * future major version.
     */
    stateMachines?: string | string[];
    layout?: Layout;
    autoplay?: boolean;
    useOffscreenRenderer?: boolean;
    /**
     * Optional tab index to set for the canvas element if there are any Focus nodes within the graphic
     */
    tabIndex?: number;
    /**
     * Optional settings for focus behavior
     */
    focusOptions?: RiveFocusOptions;
    /**
     * Allow the runtime to automatically load assets hosted in Rive's CDN.
     * enabled by default.
     */
    enableRiveAssetCDN?: boolean;
    /**
     * @experimental This API is early and may encounter breaking behavior change without a major version bump
     *
     * When to build semantic trees and the accessibility DOM overlay.
     * Defaults to {@link SemanticMode.Disabled}.
     */
    semanticsMode?: SemanticMode;
    /**
     * @experimental This API is early and may encounter breaking behavior change without a major version bump
     *
     * Optional options for the accessibility overlay container.
     */
    semanticsOptions?: RiveSemanticsOptions;
    /**
     * Turn off Rive Listeners. This means state machines that have Listeners
     * will not be invoked, and also, no event listeners pertaining to Listeners
     * will be attached to the <canvas> element
     */
    shouldDisableRiveListeners?: boolean;
    /**
     * For Rive Listeners, allows scrolling behavior to still occur on canvas elements
     * when a touch/drag action is performed on touch-enabled devices. Otherwise,
     * scroll behavior may be prevented on touch/drag actions on the canvas by default.
     */
    isTouchScrollEnabled?: boolean;
    /**
     * Enable Rive Events to be handled by the runtime. This means any special Rive Event may have
     * a side effect that takes place implicitly.
     *
     * For example, if during the render loop an OpenUrlEvent is detected, the
     * browser may try to open the specified URL in the payload.
     *
     * This flag is false by default to prevent any unwanted behaviors from taking place.
     * This means any special Rive Event will have to be handled manually by subscribing to
     * EventType.RiveEvent
     *
     * @deprecated Subscribing to Rive Events at runtime is deprecated and will be removed in a future
     * major version: please use data binding instead. See
     * {@link https://rive.app/docs/runtimes/web/rive-events} for how to migrate.
     */
    automaticallyHandleEvents?: boolean;
    /**
     * Rive will look for a default view model and view model instance to bind to the artboard
     */
    autoBind?: boolean;
    /**
     * For Rive Listeners, dispatch a pointer exit when the pointer exits the canvas.
     */
    dispatchPointerExit?: boolean;
    /**
     * Enables multi touch support
     */
    enableMultiTouch?: boolean;
    /**
     * Enum with drawing options for optimizations
     */
    drawingOptions?: DrawOptimizationOptions;
    /**
     * @experimental This API is early and may encounter breaking behavior change without a major version bump
     *
     * Render GPU Canvas content, which draws through the deferred renderer.
     *
     * Only applies when this instance loads its own file (`src`/`buffer`), where it
     * is forwarded to that file as {@link RiveFileParameters.enableGPUCanvas}. With a
     * supplied `riveFile` the file's own flag wins, since a file's mode is fixed at
     * import. False by default.
     */
    enableGPUCanvas?: boolean;
    /**
     * Emit performance.mark / performance.measure entries for load lifecycle
     * events and the first 3 render frames. Useful for profiling Rive's
     * contribution to load and render time in browser devtools.
     * False by default.
     */
    enablePerfMarks?: boolean;
    onLoad?: EventCallback;
    onLoadError?: EventCallback;
    onPlay?: EventCallback;
    onPause?: EventCallback;
    onStop?: EventCallback;
    /**
     * @deprecated Loop events are deprecated and will be removed in a future
     * major version: they are only reported for linear animation playback, which
     * is deprecated. Use a state machine to control playback and data binding to
     * react to changes instead. See
     * {@link https://rive.app/docs/editor/data-binding/migration-guide} for how
     * to migrate.
     */
    onLoop?: EventCallback;
    /**
     * @deprecated Subscribing to state change events at runtime is deprecated
     * and will be removed in a future major version: use data binding (view model
     * property observers) or state machine actions to react to changes from your
     * graphic instead. See
     * {@link https://rive.app/docs/editor/state-machine/states#actions} for how
     * to migrate.
     */
    onStateChange?: EventCallback;
    onAdvance?: EventCallback;
    assetLoader?: AssetLoadCallback;
    /**
     * @deprecated Use `onLoad()` instead
     */
    onload?: EventCallback;
    /**
     * @deprecated Use `onLoadError()` instead
     */
    onloaderror?: EventCallback;
    /**
     * @deprecated Use `onPlay()` instead
     */
    onplay?: EventCallback;
    /**
     * @deprecated Use `onPause()` instead
     */
    onpause?: EventCallback;
    /**
     * @deprecated Use `onStop()` instead
     */
    onstop?: EventCallback;
    /**
     * @deprecated Use `onLoop()` instead
     */
    onloop?: EventCallback;
    /**
     * @deprecated Use `onStateChange()` instead
     */
    onstatechange?: EventCallback;
}
export interface RiveLoadParameters {
    src?: string;
    buffer?: ArrayBuffer;
    riveFile?: RiveFile;
    autoplay?: boolean;
    autoBind?: boolean;
    artboard?: string;
    /**
     * Name of the state machine to play.
     */
    stateMachine?: string;
    /**
     * @deprecated Use the `stateMachine` parameter to play a state machine
     * instead. Support for starting playback with named animations will be
     * removed in a future major version.
     */
    animations?: string | string[];
    /**
     * @deprecated Use `stateMachine` with a single state machine name instead.
     * Support for playing multiple state machines at once will be removed in a
     * future major version.
     */
    stateMachines?: string | string[];
    useOffscreenRenderer?: boolean;
    shouldDisableRiveListeners?: boolean;
    tabIndex?: number;
    semanticsMode?: SemanticMode;
    semanticsOptions?: RiveSemanticsOptions;
    /**
     * @experimental This API is early and may encounter breaking behavior change without a major version bump
     *
     * Render GPU Canvas content, which draws through the deferred renderer. Forwarded
     * to the file this instance loads; with a supplied `riveFile` the file's flag wins.
     * False by default.
     */
    enableGPUCanvas?: boolean;
}
export interface RiveResetParameters {
    artboard?: string;
    /**
     * Name of the state machine to play.
     */
    stateMachine?: string;
    /**
     * @deprecated Use the `stateMachine` parameter to play a state machine
     * instead. Support for starting playback with named animations will be
     * removed in a future major version.
     */
    animations?: string | string[];
    /**
     * @deprecated Use `stateMachine` with a single state machine name instead.
     * Support for playing multiple state machines at once will be removed in a
     * future major version.
     */
    stateMachines?: string | string[];
    autoplay?: boolean;
    autoBind?: boolean;
}
export interface RiveFileParameters {
    src?: string;
    buffer?: ArrayBuffer;
    assetLoader?: AssetLoadCallback;
    enableRiveAssetCDN?: boolean;
    onLoad?: EventCallback;
    onLoadError?: EventCallback;
    /**
     * Emit performance.mark / performance.measure entries for load lifecycle
     * events. False by default.
     */
    enablePerfMarks?: boolean;
    /**
     * @experimental This API is early and may encounter breaking behavior change without a major version bump
     *
     * Render GPU Canvas content in this file, importing it through a deferred
     * rendering session.
     *
     * Fixed at import and has no setter: a file's resources are typed by the factory
     * that made them and can never switch. The session records for the one canvas that
     * displays the file, so a second Rive instance sharing this file re-imports it into
     * a session of its own.
     * False by default.
     */
    enableGPUCanvas?: boolean;
}
export declare class RiveFile implements rc.FinalizableTarget {
    private static readonly missingErrorMessage;
    private static readonly fileLoadErrorMessage;
    private src;
    private buffer;
    private runtime;
    private file;
    private assetLoader;
    private enableRiveAssetCDN;
    private enablePerfMarks;
    private eventManager;
    private referenceCount;
    private destroyed;
    selfUnref: boolean;
    private bindableArtboards;
    private deferred;
    private session;
    private _sessionClaimed;
    private fileFinalizer;
    private boundElsewhereWarned;
    private static deferredUnsupportedWarned;
    constructor(params: RiveFileParameters);
    private releaseFile;
    private releaseSession;
    private releaseBindableArtboards;
    private initData;
    private loadRiveFileBytes;
    private loadRuntime;
    init(): Promise<void>;
    private fireLoadError;
    /**
     * Subscribe to Rive-generated events
     * @param type the type of event to subscribe to
     * @param callback callback to fire when the event occurs
     */
    on(type: EventType, callback: EventCallback): void;
    /**
     * Unsubscribes from a Rive-generated event
     * @param type the type of event to unsubscribe from
     * @param callback the callback to unsubscribe
     */
    off(type: EventType, callback: EventCallback): void;
    cleanup(): void;
    private static makeDeferredSession;
    /**
     * @internal The deferred session this file imported through, or null if it
     * was imported in immediate mode.
     */
    get deferredSession(): rc.DeferredSession | null;
    /**
     * @internal Whether deferred was asked for, even when this build could not
     * honor it and imported immediate.
     */
    get deferredRequested(): boolean;
    /**
     * @internal Whether this file's session has ever been attached to a renderer.
     * Attaching is once per session, so a claimed file re-imports for the next
     * instance even after the renderer it was bound to is gone.
     */
    get sessionClaimed(): boolean;
    /**
     * @internal Marks this file's session as spent. There is no matching release:
     * a session that has been attached can never replay for another renderer.
     */
    claimSession(): void;
    /**
     * @internal One warning per file however many instances collide on it.
     */
    warnBoundElsewhereOnce(): void;
    /**
     * @internal Re-imports this file from its retained buffer into a mode of its
     * own. The copy is owned by whoever asked for it and never joins this file's
     * reference count.
     */
    reimport(deferred: boolean): Promise<RiveFile>;
    /**
     * Unsubscribes all Rive listeners from an event type, or everything if no type is
     * given
     * @param type the type of event to unsubscribe from, or all types if
     * undefined
     */
    removeAllRiveEventListeners(type?: EventType): void;
    getInstance(): rc.File;
    destroyIfUnused(): void;
    private createBindableArtboard;
    /**
     * @deprecated This function is deprecated. For better stability and memory management
     * use `getBindableArtboard()` instead.
     * @param {string} name - The name of the artboard.
     * @returns {Artboard} The artboard to bind to.
     */
    getArtboard(name: string): Artboard | null;
    getBindableArtboard(name: string): BindableArtboard | null;
    getDefaultBindableArtboard(): BindableArtboard | null;
    internalBindableArtboardFromArtboard(artboard: rc.Artboard): BindableArtboard | null;
    viewModelByName(name: string): ViewModel | null;
    /**
     * @returns the names of the file's global view models, in file order.
     */
    globalViewModelNames(): string[];
}
export declare class Rive {
    private readonly canvas;
    private src;
    private buffer;
    private _layout;
    private renderer;
    private loaded;
    private destroyed;
    private _observed;
    /**
     * Tracks if a Rive file is loaded; we need this in addition to loaded as some
     * commands (e.g. contents) can be called as soon as the file is loaded.
     * However, playback commands need to be queued and run in order once initial
     * animations and autoplay has been sorted out. This applies to play, pause,
     * and start.
     */
    private readyForPlaying;
    private runtime;
    private deferredRenderer;
    private ownsRiveFile;
    private artboard;
    private eventCleanup;
    private _keyboardInteractions;
    private file;
    private riveFile;
    private eventManager;
    private taskQueue;
    private animator;
    private assetLoader;
    private static readonly missingErrorMessage;
    private static readonly cleanupErrorMessage;
    /**
     * Deprecation warnings to silence, by {@link DeprecationId}. Each warning
     * prints the id needed to silence it, so you can copy it out of the console.
     *
     * ```ts
     * Rive.suppressDeprecationWarnings = ["rive-events", "text-runs"];
     * ```
     *
     * Assigning replaces the whole list.
     * There is no option to silence everything
     */
    static get suppressDeprecationWarnings(): readonly DeprecationId[];
    static set suppressDeprecationWarnings(ids: readonly DeprecationId[]);
    private shouldDisableRiveListeners;
    private automaticallyHandleEvents;
    private dispatchPointerExit;
    private enableMultiTouch;
    private enableRiveAssetCDN;
    private semanticsMode;
    private semanticsOptions;
    /** True when this instance may drain semantics and render the overlay. */
    private _semanticsActive;
    private _volume;
    private _artboardWidth;
    private _artboardHeight;
    private _devicePixelRatioUsed;
    private _hasZeroSize;
    private _needsRedraw;
    private _currentCanvasWidth;
    private _currentCanvasHeight;
    private _audioEventListener;
    private _boundDraw;
    private _pageVisibilityHandler;
    private _explicitlyStoppedRendering;
    private _viewModelInstance;
    private _globalViewModelInstances;
    private _dataEnums;
    private _tabIndex;
    private _prevHasFocus;
    private _prevWantsTextInputSession;
    private _inPointerDownDrain;
    private _focusOptions;
    private _semanticTree;
    private _accessibilityOverlay;
    /**
     * True when an input to the accessibility overlay's artboard→canvas transform
     * (layout fit/alignment/bounds, devicePixelRatio, or layout scale) has changed
     * and the matrix must be recomputed on the next overlay update. Avoids calling
     * computeAlignment every frame when only the semantic tree changed.
     */
    private _overlayTransformDirty;
    private readonly _instanceId;
    private drawOptimization;
    private enablePerfMarks;
    durations: number[];
    frameTimes: number[];
    frameCount: number;
    isTouchScrollEnabled: boolean;
    constructor(params: RiveParameters);
    get viewModelCount(): number;
    static new(params: RiveParameters): Rive;
    /**
     * @experimental Turns on semantics and the accessibility overlay for this
     * instance. Idempotent; safe to call before or after load. Use this to drive
     * a consumer-controlled accessibility toggle when constructed with the
     * default {@link SemanticMode.Disabled}.
     */
    enableSemantics(): void;
    private activateSemantics;
    private syncSemanticsOnStateMachines;
    /**
     * Tears down the semantic tree and accessibility overlay. The overlay captures the
     * active state machine in its action closures, so it must not outlive the
     * instances it points at (reset/load delete them)
     */
    private cleanupSemantics;
    private onSystemAudioChanged;
    private onCanvasResize;
    private init;
    /**
     * Setup Rive Listeners on the canvas
     * @param riveListenerOptions - Enables TouchEvent events on the canvas. Set to true to allow
     * touch scrolling on the canvas element on touch-enabled devices
     * i.e. { isTouchScrollEnabled: true }
     */
    setupRiveListeners(riveListenerOptions?: SetupRiveListenersOptions): void;
    private isEditingHostFocused;
    private get focusStateMachine();
    /**
     * Wire keyboard interactions when a playing state machine has focus nodes.
     * Called at listener setup and lazily each frame so late-bound bindable artboards work.
     */
    private ensureKeyboardInteractions;
    /** Runs inside touchend/mouseup so focusing the proxy raises the mobile keyboard. */
    private summonKeyboardForGesture;
    /** expectsKeyboardInput, and (with semantics on) the focused node is a textField. */
    private wantsTextInputSession;
    private advanceAndDrainForPointer;
    private cleanupKeyboardInteractions;
    /**
     * Remove Rive Listeners setup on the canvas
     */
    removeRiveListeners(): void;
    /**
     * If the instance has audio and the system audio is not ready
     * we hook the instance to the audio manager
     */
    private initializeAudio;
    private initArtboardSize;
    private initData;
    /**
     * Settles which rendering mode this Rive instance runs in. The file dictates: its rendering mode
     * is fixed at import, and an immediate renderer silently drops a deferred
     * file's resources. Every mismatch warns and degrades to something that
     * renders, so users shouldn't have a blank canvas. A fallback self-reimport replaces `this.riveFile`;
     * only a file this instance imported is released when that happens.
     */
    private resolveDeferredRendering;
    private initArtboard;
    drawFrame(): void;
    private _canvasSizeChanged;
    private _deferredWorkPending;
    /** Rive can move focus on its own, so reconcile the text session and DOM focus each frame. */
    private pollFocusState;
    /** Begin/end the text session on wantsSession edges; decorate the proxy while it has DOM focus. */
    private syncTextInputSession;
    /** Mirror Rive's hasFocus into the keyboard session state and, on opt-in, canvas focus. */
    private syncRiveFocus;
    private lastRenderTime;
    private frameRequestId;
    /**
     * Used be draw to track when a second of active rendering time has passed.
     * Used for debugging purposes
     */
    private renderSecondTimer;
    /**
     * Handles important sequence of reporting Rive events, advancing the state machine or animation, and invoking various callbacks
     * due to state changes, view model property changes, etc.
     *
     * @param elapsedTime time to advance the state machine by
     */
    private advanceAndReportChanges;
    /**
     * Draw rendering loop; renders animation frames at the correct time interval.
     * @param time the time at which to render a frame
     */
    private draw;
    /**
     * Align the renderer
     */
    private alignRenderer;
    get fps(): number;
    get frameTime(): string | 0;
    /**
     * Cleans up all Wasm-generated objects that need to be manually destroyed:
     * artboard instances, animation instances, state machine instances,
     * renderer instance, file and runtime.
     *
     * Once this is called, you will need to initialise a new instance of the
     * Rive class
     */
    cleanup(): void;
    /**
     * Drops this instance's hold on `this.riveFile`. A reference taken through
     * getInstance() is given back; a file we imported but never referenced is
     * released outright so its session goes with it. A caller-supplied file we
     * never referenced is left alone.
     *
     * `isTeardown` distinguishes cleanup() from a reload. Teardown always hands
     * the reference back, as it always has. A reload must not do that for a
     * caller-supplied file: a RiveFile carries no reference for its creator, so
     * releasing here would take the last one and destroy a file the caller still
     * holds.
     */
    private releaseCurrentRiveFile;
    /**
     * Cleans up the Renderer object. Only call this API if you no longer
     * need to render Rive content in your session.
     */
    deleteRiveRenderer(): void;
    /**
     * @experimental This API is early and may encounter breaking behavior change without a major version bump
     *
     * Whether this instance is rendering through a deferred session. False whenever
     * a fallback ran, whatever was requested.
     */
    get deferredRendererActive(): boolean;
    /**
     * Cleans up any Wasm-generated objects that need to be manually destroyed:
     * artboard instances, animation instances, state machine instances.
     *
     * Once this is called, things will need to be reinitialized or bad things
     * might happen.
     */
    cleanupInstances(): void;
    /**
     * Tries to query the setup Artboard for a text run node with the given name.
     *
     * @param textRunName - Name of the text run node associated with a text object
     * @returns - TextValueRun node or undefined if the text run cannot be queried
     */
    private retrieveTextRun;
    /**
     * Returns a string from a given text run node name, or undefined if the text run
     * cannot be queried.
     *
     * @deprecated Text run APIs are deprecated: use data binding instead. See
     * {@link https://rive.app/docs/editor/data-binding/migration-guide#updating-text-runs-at-runtime}
     * for how to migrate.
     * @param textRunName - Name of the text run node associated with a text object
     * @returns - String value of the text run node or undefined
     */
    getTextRunValue(textRunName: string): string | undefined;
    /**
     * Sets a text value for a given text run node name if possible
     *
     * @deprecated Text run APIs are deprecated: use data binding instead. See
     * {@link https://rive.app/docs/editor/data-binding/migration-guide#updating-text-runs-at-runtime}
     * for how to migrate.
     * @param textRunName - Name of the text run node associated with a text object
     * @param textRunValue - String value to set on the text run node
     */
    setTextRunValue(textRunName: string, textRunValue: string): void;
    /**
     * Warns when playback-control names match linear animations in the
     * Animator's instanced context; state machine playback remain supported.
     *
     * Remove for v3 release
     */
    private warnIfLinearAnimationNames;
    /**
     * Plays specified animations or state machines; if none specified, it
     * unpauses everything.
     * @param animationNames Animation or state machine name(s) to play.
     *
     * Deprecated usage: passing linear animation names (control playback with a
     * state machine instead) and passing an array of names (this parameter
     * becomes a single string in the next major version).
     */
    play(animationNames?: string | string[], autoplay?: true): void;
    /**
     * Pauses specified animations or state machines; if none specified, pauses
     * all.
     * @param animationNames Animation or state machine name(s) to pause.
     *
     * Deprecated usage: passing linear animation names (control playback with a
     * state machine instead) and passing an array of names (this parameter
     * becomes a single string in the next major version).
     */
    pause(animationNames?: string | string[]): void;
    /**
     * Scrubs specified animations to the given time; if none specified, scrubs
     * all of them.
     * @deprecated `scrub()` will be removed in a future major version: use a
     * state machine to control playback instead
     */
    scrub(animationNames?: string | string[], value?: number): void;
    /**
     * Stops specified animations or state machines; if none specified, stops
     * them all.
     * @param animationNames Animation or state machine name(s) to stop.
     *
     * Deprecated usage: passing linear animation names (control playback with a
     * state machine instead) and passing an array of names (this parameter
     * becomes a single string in the next major version).
     */
    stop(animationNames?: string | string[] | undefined): void;
    /**
     * Resets the animation
     * @param artboard the name of the artboard, or default if none given
     * @param stateMachine the name of the state machine for playback
     * @param autoplay whether to autoplay when reset, defaults to false
     *
     */
    reset(params?: RiveResetParameters): void;
    load(params: RiveLoadParameters): void;
    set layout(layout: Layout);
    /**
     * Returns the current layout. Note that layout should be treated as
     * immutable. If you want to change the layout, create a new one use the
     * layout setter
     */
    get layout(): Layout;
    /**
     * Sets the layout bounds to the current canvas size; this is typically called
     * when the canvas is resized
     */
    resizeToCanvas(): void;
    /**
     * Accounts for devicePixelRatio as a multiplier to render the size of the canvas drawing surface.
     * Uses the size of the backing canvas to set new width/height attributes. Need to re-render
     * and resize the layout to match the new drawing surface afterwards.
     * Useful function for consumers to include in a window resize listener.
     *
     * This method will set the {@link devicePixelRatioUsed} property.
     *
     * Optionally, you can provide a {@link customDevicePixelRatio} to provide a
     * custom value.
     */
    resizeDrawingSurfaceToCanvas(customDevicePixelRatio?: number): void;
    get source(): string;
    /**
     * Returns the name of the active artboard
     */
    get activeArtboard(): string;
    /**
     * Returns the semantic tree model when semantics are enabled, or null.
     * The overlay and external consumers use this to inspect the
     * current state of the semantic tree.
     */
    get semanticTree(): SemanticTreeModel | null;
    /**
     * Returns the accessibility overlay when semantics are enabled, or null.
     * External consumers can use this to inspect the
     * current state of the accessibility overlay for this instance.
     */
    get accessibilityOverlay(): AccessibilityOverlay | null;
    get animationNames(): string[];
    /**
     * Returns a list of state machine names from the current artboard
     */
    get stateMachineNames(): string[];
    /**
     * Returns the inputs for the specified instanced state machine, or an empty
     * list if the name is invalid or the state machine is not instanced. Returns
     * undefined if the file is not loaded yet.
     *
     * @deprecated State machine inputs are deprecated: use data binding
     * properties instead. See
     * {@link https://rive.app/docs/editor/data-binding/migration-guide#state-machine-inputs}
     * for how to migrate.
     * @param name the state machine name
     * @returns the inputs for the named state machine or undefined
     */
    stateMachineInputs(name: string): StateMachineInput[] | undefined;
    private retrieveInputAtPath;
    /**
     * Set the boolean input with the provided name at the given path with value
     * @deprecated State machine inputs are deprecated: use data binding
     * properties instead. See
     * {@link https://rive.app/docs/editor/data-binding/migration-guide#state-machine-inputs}
     * for how to migrate.
     * @param input the state machine input name
     * @param value the value to set the input to
     * @param path the path the input is located at an artboard level
     */
    setBooleanStateAtPath(inputName: string, value: boolean, path: string): void;
    /**
     * Set the number input with the provided name at the given path with value
     * @deprecated State machine inputs are deprecated: use data binding
     * properties instead. See
     * {@link https://rive.app/docs/editor/data-binding/migration-guide#state-machine-inputs}
     * for how to migrate.
     * @param input the state machine input name
     * @param value the value to set the input to
     * @param path the path the input is located at an artboard level
     */
    setNumberStateAtPath(inputName: string, value: number, path: string): void;
    /**
     * Fire the trigger with the provided name at the given path
     * @deprecated State machine inputs are deprecated: use data binding
     * properties instead. See
     * {@link https://rive.app/docs/editor/data-binding/migration-guide#state-machine-inputs}
     * for how to migrate.
     * @param input the state machine input name
     * @param path the path the input is located at an artboard level
     */
    fireStateAtPath(inputName: string, path: string): void;
    private retrieveTextAtPath;
    /**
     * Retrieves the text value for a specified text run at a given path
     * @param textName The name of the text run
     * @param path The path to the text run within the artboard
     * @returns The text value of the text run, or undefined if not found
     *
     * @example
     * // Get the text value for a text run named "title" at one nested artboard deep
     * const titleText = riveInstance.getTextRunValueAtPath("title", "artboard1");
     *
     * @example
     * // Get the text value for a text run named "subtitle" within a nested group two artboards deep
     * const subtitleText = riveInstance.getTextRunValueAtPath("subtitle", "group/nestedGroup");
     *
     * @remarks
     * If the text run cannot be found at the specified path, a warning will be logged to the console.
     *
     * @deprecated Text run APIs are deprecated: use data binding instead. See
     * {@link https://rive.app/docs/editor/data-binding/migration-guide#updating-text-runs-at-runtime}
     * for how to migrate.
     */
    getTextRunValueAtPath(textName: string, path: string): string | undefined;
    /**
     * Sets the text value for a specified text run at a given path
     * @param textName The name of the text run
     * @param value The new text value to set
     * @param path The path to the text run within the artboard
     * @returns void
     *
     * @example
     * // Set the text value for a text run named "title" at one nested artboard deep
     * riveInstance.setTextRunValueAtPath("title", "New Title", "artboard1");
     *
     * @example
     * // Set the text value for a text run named "subtitle" within a nested group two artboards deep
     * riveInstance.setTextRunValueAtPath("subtitle", "New Subtitle", "group/nestedGroup");
     *
     * @remarks
     * If the text run cannot be found at the specified path, a warning will be logged to the console.
     *
     * @deprecated Text run APIs are deprecated: use data binding instead. See
     * {@link https://rive.app/docs/editor/data-binding/migration-guide#updating-text-runs-at-runtime}
     * for how to migrate.
     */
    setTextRunValueAtPath(textName: string, value: string, path: string): void;
    get playingStateMachineNames(): string[];
    get playingAnimationNames(): string[];
    get pausedAnimationNames(): string[];
    /**
     *  Returns a list of paused machine names
     * @returns a list of state machine names that are paused
     */
    get pausedStateMachineNames(): string[];
    /**
     * @returns true if any animation is playing
     */
    get isPlaying(): boolean;
    /**
     * @returns true if all instanced animations are paused
     */
    get isPaused(): boolean;
    /**
     * @returns true if no animations are playing or paused
     */
    get isStopped(): boolean;
    /**
     * @returns the bounds of the current artboard, or undefined if the artboard
     * isn't loaded yet.
     */
    get bounds(): Bounds;
    /**
     * Subscribe to Rive-generated events
     *
     * Note: subscribing to {@link EventType.RiveEvent},
     * {@link EventType.StateChange}, or {@link EventType.Loop} is deprecated;
     * use data binding instead. See
     * {@link https://rive.app/docs/runtimes/web/rive-events} (Rive Events) and
     * {@link https://rive.app/docs/editor/data-binding/migration-guide} for how
     * to migrate Rive graphics to a data binding workflow instead.
     * @param type the type of event to subscribe to
     * @param callback callback to fire when the event occurs
     */
    on(type: EventType, callback: EventCallback): void;
    /**
     * Unsubscribes from a Rive-generated event
     * @param type the type of event to unsubscribe from
     * @param callback the callback to unsubscribe
     */
    off(type: EventType, callback: EventCallback): void;
    /**
     * Unsubscribes from a Rive-generated event
     * @deprecated
     * @param callback the callback to unsubscribe from
     */
    unsubscribe(type: EventType, callback: EventCallback): void;
    /**
     * Unsubscribes all Rive listeners from an event type, or everything if no type is
     * given
     * @param type the type of event to unsubscribe from, or all types if
     * undefined
     */
    removeAllRiveEventListeners(type?: EventType): void;
    /**
     * Unsubscribes all listeners from an event type, or everything if no type is
     * given
     * @deprecated
     * @param type the type of event to unsubscribe from, or all types if
     * undefined
     */
    unsubscribeAll(type?: EventType): void;
    /**
     * Stops the rendering loop; this is different from pausing in that it doesn't
     * change the state of any animation. It stops rendering from occurring. This
     * is designed for situations such as when Rive isn't visible.
     *
     * The only way to start rendering again is to call `startRendering`.
     * Animations that are marked as playing will start from the position that
     * they would have been at if rendering had not been stopped.
     */
    stopRendering(): void;
    /**
     * Starts the rendering loop if it has been previously stopped. If the
     * renderer is already active, then this will have zero effect.
     */
    startRendering(): void;
    private scheduleRendering;
    /**
     * Called when document.visibilitychange fires (tab change, window minimize, etc.).
     * Cancels the rAF loop on hide and resets the time reference so that no accumulated time is
     * applied to state machines when the tab becomes visible again. This prevents state machine
     * advances with large time deltas when rAF starts up again.
     */
    private _onPageVisibilityChange;
    /**
     * Enables frames-per-second (FPS) reporting for the runtime
     * If no callback is provided, Rive will append a fixed-position div at the top-right corner of
     * the page with the FPS reading
     * @param fpsCallback - Callback from the runtime during the RAF loop that supplies the FPS value
     */
    enableFPSCounter(fpsCallback?: FPSCallback): void;
    /**
     * Disables frames-per-second (FPS) reporting for the runtime
     */
    disableFPSCounter(): void;
    /**
     * Returns the contents of a Rive file: the artboards, animations, and state machines
     */
    get contents(): RiveFileContents;
    /**
     * Getter / Setter for the volume of the artboard
     */
    get volume(): number;
    set volume(value: number);
    /**
     * The width of the artboard.
     *
     * This will return 0 if the artboard is not loaded yet and a custom
     * width has not been set.
     *
     * Do not set this value manually when using {@link resizeDrawingSurfaceToCanvas}
     * with a {@link Layout.fit} of {@link Fit.Layout}, as the artboard width is
     * automatically set.
     */
    get artboardWidth(): number;
    set artboardWidth(value: number);
    /**
     * The height of the artboard.
     *
     * This will return 0 if the artboard is not loaded yet and a custom
     * height has not been set.
     *
     * Do not set this value manually when using {@link resizeDrawingSurfaceToCanvas}
     * with a {@link Layout.fit} of {@link Fit.Layout}, as the artboard height is
     * automatically set.
     */
    get artboardHeight(): number;
    set artboardHeight(value: number);
    /**
     * Reset the artboard size to its original values.
     */
    resetArtboardSize(): void;
    /**
     * The device pixel ratio used in rendering and canvas/artboard resizing.
     *
     * This value will be overidden by the device pixel ratio used in
     * {@link resizeDrawingSurfaceToCanvas}. If you use that method, do not set this value.
     */
    get devicePixelRatioUsed(): number;
    set devicePixelRatioUsed(value: number);
    private reportDisplayScale;
    /**
     * Sets the main view model instance and applies it (rebinds). Equivalent to
     * `setViewModelInstance(vmi)` followed by `bind()`.
     */
    bindViewModelInstance(viewModelInstance: ViewModelInstance | null): void;
    /**
     * Sets the main view model instance in the data context WITHOUT rebinding.
     * Call {@link bind} to apply. Use this with {@link setGlobalViewModelInstance}
     * to batch multiple changes into a single rebind.
     */
    setViewModelInstance(viewModelInstance: ViewModelInstance | null): void;
    /**
     * Applies any pending `set*` view model instance changes by rebinding the
     * data binds once.
     * Implicitly creates and binds any view models that have not been set.
     */
    bind(): void;
    get viewModelInstance(): ViewModelInstance | null;
    /**
     * Sets (or replaces) the global view model instance for the given global view
     * model name in the data context WITHOUT rebinding. The main instance and any
     * other globals keep their order. Call {@link bind} to apply — batch several
     * `set*` calls then a single `bind()` to avoid rebinding per set.
     * @param name - the name of the global view model
     * @param viewModelInstance - the instance to set for that global
     * @returns whether the instance was set (false if `name` does not match a
     * global view model in the file)
     */
    setGlobalViewModelInstance(name: string, viewModelInstance: ViewModelInstance): boolean;
    /**
     * @param name - the name of the global view model
     * @returns the global view model instance bound under the given name — the
     * instance set via {@link setGlobalViewModelInstance} or one created by
     * auto-bind — or null if none has been set/created for that name (globals are
     * not auto-created; the getter never creates one).
     */
    globalViewModelInstance(name: string): ViewModelInstance | null;
    /**
     * @returns the names of the file's global view models, in file order. Use
     * these with {@link setGlobalViewModelInstance} / {@link globalViewModelInstance}.
     */
    globalViewModelNames(): string[];
    viewModelByIndex(index: number): ViewModel | null;
    viewModelByName(name: string): ViewModel | null;
    enums(): DataEnum[];
    defaultViewModel(): ViewModel | null;
    /**
     * @deprecated This function is deprecated. For better stability and memory management
     * use `getBindableArtboard()` instead.
     * @param {string} name - The name of the artboard.
     * @returns {Artboard} The artboard to bind to.
     */
    getArtboard(name: string): Artboard | null;
    getBindableArtboard(name: string): BindableArtboard | null;
    getDefaultBindableArtboard(): BindableArtboard | null;
    /**
     * Clear focus applicable to active state machines with focus nodes. Useful if users want to
     * reset focus state and behavior within the Rive graphic at any point (i.e. blurring off the canvas)
     */
    clearFocus(): void;
}
export declare enum DataType {
    none = "none",
    string = "string",
    number = "number",
    boolean = "boolean",
    color = "color",
    list = "list",
    enumType = "enumType",
    trigger = "trigger",
    viewModel = "viewModel",
    integer = "integer",
    listIndex = "listIndex",
    image = "image",
    artboard = "artboard"
}
export declare class ViewModel {
    private _viewModel;
    constructor(viewModel: rc.ViewModel);
    get instanceCount(): number;
    get name(): string;
    instanceByIndex(index: number): ViewModelInstance | null;
    instanceByName(name: string): ViewModelInstance | null;
    defaultInstance(): ViewModelInstance | null;
    instance(): ViewModelInstance;
    get properties(): rc.ViewModelProperty[];
    get instanceNames(): string[];
}
export declare class DataEnum {
    private _dataEnum;
    constructor(dataEnum: rc.DataEnum);
    get name(): string;
    get values(): string[];
}
export declare class ViewModelInstance {
    private _runtimeInstance;
    private _parents;
    private _children;
    private _viewModelInstances;
    private _propertiesWithCallbacks;
    private _referenceCount;
    selfUnref: boolean;
    constructor(runtimeInstance: rc.ViewModelInstance, parent: ViewModelInstance | null);
    get runtimeInstance(): rc.ViewModelInstance | null;
    get nativeInstance(): rc.ViewModelInstance | null;
    handleCallbacks(): void;
    addParent(parent: ViewModelInstance): void;
    removeParent(parent: ViewModelInstance): void;
    addToPropertyCallbacks(property: ViewModelInstanceValue): void;
    removeFromPropertyCallbacks(property: ViewModelInstanceValue): void;
    addToViewModelCallbacks(instance: ViewModelInstance): void;
    removeFromViewModelCallbacks(instance: ViewModelInstance): void;
    private clearCallbacks;
    private propertyFromPath;
    private viewModelFromPathSegments;
    private propertyFromPathSegments;
    private internalViewModelInstance;
    /**
     * method to access a property instance of type number belonging
     * to the view model instance or to a nested view model instance
     * @param path - path to the number property
     */
    number(path: string): ViewModelInstanceNumber | null;
    /**
     * method to access a property instance of type string belonging
     * to the view model instance or to a nested view model instance
     * @param path - path to the string property
     */
    string(path: string): ViewModelInstanceString | null;
    /**
     * method to access a property instance of type boolean belonging
     * to the view model instance or to a nested view model instance
     * @param path - path to the boolean property
     */
    boolean(path: string): ViewModelInstanceBoolean | null;
    /**
     * method to access a property instance of type color belonging
     * to the view model instance or to a nested view model instance
     * @param path - path to the ttrigger property
     */
    color(path: string): ViewModelInstanceColor | null;
    /**
     * method to access a property instance of type trigger belonging
     * to the view model instance or to a nested view model instance
     * @param path - path to the trigger property
     */
    trigger(path: string): ViewModelInstanceTrigger | null;
    /**
     * method to access a property instance of type enum belonging
     * to the view model instance or to a nested view model instance
     * @param path - path to the enum property
     */
    enum(path: string): ViewModelInstanceEnum | null;
    /**
     * method to access a property instance of type list belonging
     * to the view model instance or to a nested view model instance
     * @param path - path to the list property
     */
    list(path: string): ViewModelInstanceList | null;
    /**
     * method to access a view model property instance belonging
     * to the view model instance or to a nested view model instance
     * @param path - path to the image property
     */
    image(path: string): ViewModelInstanceAssetImage | null;
    /**
     * method to access a view model property instance belonging
     * to the view model instance or to a nested view model instance
     * @param path - path to the font property
     */
    font(path: string): ViewModelInstanceAssetFont | null;
    /**
     * method to access an artboard property instance belonging
     * to the view model instance or to a nested view model instance
     * @param path - path to the image property
     */
    artboard(path: string): ViewModelInstanceArtboard | null;
    /**
     * method to access a view model property instance belonging
     * to the view model instance or to a nested view model instance
     * @param path - path to the view model property
     */
    viewModel(path: string): ViewModelInstance | null;
    internalReplaceViewModel(name: string, value: ViewModelInstance): boolean;
    /**
     * method to replace a view model property with another view model value
     * @param path - path to the view model property
     * @param value - view model that will replace the original
     */
    replaceViewModel(path: string, value: ViewModelInstance): boolean;
    incrementReferenceCount(): void;
    decrementReferenceCount(): void;
    get properties(): rc.ViewModelProperty[];
    /**
     * Get the name of the ViewModel definition this instance was created from.
     */
    get viewModelName(): string;
    internalIncrementReferenceCount(): void;
    cleanup(): void;
}
export declare class ViewModelInstanceValue {
    protected _parentViewModel: ViewModelInstance;
    protected callbacks: EventCallback[];
    protected _viewModelInstanceValue: rc.ViewModelInstanceValue;
    constructor(instance: rc.ViewModelInstanceValue, parent: ViewModelInstance);
    on(callback: EventCallback): void;
    off(callback?: EventCallback): void;
    internalHandleCallback(callback: Function): void;
    handleCallbacks(): void;
    clearChanges(): void;
    clearCallbacks(): void;
    get name(): string;
}
export declare class ViewModelInstanceString extends ViewModelInstanceValue {
    constructor(instance: rc.ViewModelInstanceString, parent: ViewModelInstance);
    get value(): string;
    set value(val: string);
    internalHandleCallback(callback: Function): void;
}
export declare class ViewModelInstanceNumber extends ViewModelInstanceValue {
    constructor(instance: rc.ViewModelInstanceNumber, parent: ViewModelInstance);
    get value(): number;
    set value(val: number);
    internalHandleCallback(callback: Function): void;
}
export declare class ViewModelInstanceBoolean extends ViewModelInstanceValue {
    constructor(instance: rc.ViewModelInstanceBoolean, parent: ViewModelInstance);
    get value(): boolean;
    set value(val: boolean);
    internalHandleCallback(callback: Function): void;
}
export declare class ViewModelInstanceTrigger extends ViewModelInstanceValue {
    constructor(instance: rc.ViewModelInstanceTrigger, parent: ViewModelInstance);
    trigger(): void;
    internalHandleCallback(callback: Function): void;
}
export declare class ViewModelInstanceEnum extends ViewModelInstanceValue {
    constructor(instance: rc.ViewModelInstanceEnum, parent: ViewModelInstance);
    get value(): string;
    set value(val: string);
    set valueIndex(val: number);
    get valueIndex(): number;
    get values(): string[];
    internalHandleCallback(callback: Function): void;
}
export declare class ViewModelInstanceList extends ViewModelInstanceValue {
    constructor(instance: rc.ViewModelInstanceList, parent: ViewModelInstance);
    get length(): number;
    addInstance(instance: ViewModelInstance): void;
    addInstanceAt(instance: ViewModelInstance, index: number): boolean;
    removeInstance(instance: ViewModelInstance): void;
    removeInstanceAt(index: number): void;
    instanceAt(index: number): ViewModelInstance | null;
    swap(a: number, b: number): void;
    internalHandleCallback(callback: Function): void;
}
export declare class ViewModelInstanceColor extends ViewModelInstanceValue {
    constructor(instance: rc.ViewModelInstanceColor, parent: ViewModelInstance);
    get value(): number;
    set value(val: number);
    rgb(r: number, g: number, b: number): void;
    rgba(r: number, g: number, b: number, a: number): void;
    argb(a: number, r: number, g: number, b: number): void;
    alpha(a: number): void;
    opacity(o: number): void;
    internalHandleCallback(callback: Function): void;
}
export declare class ViewModelInstanceAssetImage extends ViewModelInstanceValue {
    constructor(instance: rc.ViewModelInstanceAssetImage, root: ViewModelInstance);
    set value(image: rc.Image | null);
    internalHandleCallback(callback: Function): void;
}
export declare class ViewModelInstanceAssetFont extends ViewModelInstanceValue {
    constructor(instance: rc.ViewModelInstanceAssetFont, root: ViewModelInstance);
    set value(font: rc.Font | null);
    internalHandleCallback(callback: Function): void;
}
export declare class ViewModelInstanceArtboard extends ViewModelInstanceValue {
    constructor(instance: rc.ViewModelInstanceArtboard, root: ViewModelInstance);
    set value(artboard: BaseArtboard | null);
    internalHandleCallback(callback: Function): void;
}
/**
 * Contents of a state machine input
 */
interface StateMachineInputContents {
    name: string;
    type: StateMachineInputType;
    initialValue?: boolean | number;
}
/**
 * Contents of a state machine
 */
interface StateMachineContents {
    name: string;
    inputs: StateMachineInputContents[];
}
/**
 * Contents of an artboard
 */
interface ArtboardContents {
    animations: string[];
    stateMachines: StateMachineContents[];
    name: string;
}
/**
 * contents of a Rive file
 */
interface RiveFileContents {
    artboards?: ArtboardContents[];
}
export declare const Testing: {
    EventManager: typeof EventManager;
    TaskQueueManager: typeof TaskQueueManager;
};
/**
 * Decodes bytes into an audio asset.
 *
 * Be sure to call `.unref()` on the audio once it is no longer needed. This
 * allows the engine to clean it up when it is not used by any more animations.
 */
export declare const decodeAudio: (bytes: Uint8Array) => Promise<AudioWrapper>;
/**
 * Decodes bytes into an image.
 *
 * Be sure to call `.unref()` on the image once it is no longer needed. This
 * allows the engine to clean it up when it is not used by any more animations.
 */
export declare const decodeImage: (bytes: Uint8Array) => Promise<ImageWrapper>;
/**
 * Decodes bytes into a font.
 *
 * Be sure to call `.unref()` on the font once it is no longer needed. This
 * allows the engine to clean it up when it is not used by any more animations.
 */
export declare const decodeFont: (bytes: Uint8Array) => Promise<FontWrapper>;
