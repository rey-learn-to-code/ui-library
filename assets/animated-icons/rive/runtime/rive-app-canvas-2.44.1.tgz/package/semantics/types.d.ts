import type { SemanticsDiffNode, SemanticsDiff } from "../rive_advanced.mjs";
export type { SemanticsDiffNode, SemanticsDiff, };
export declare const SemanticRole: {
    readonly none: 0;
    readonly button: 1;
    readonly link: 2;
    readonly checkbox: 3;
    readonly switchControl: 4;
    readonly slider: 5;
    readonly textField: 6;
    readonly text: 7;
    readonly image: 8;
    readonly group: 9;
    readonly list: 10;
    readonly listItem: 11;
    readonly tab: 12;
    readonly tabList: 13;
    readonly dialog: 14;
    readonly alertDialog: 15;
    readonly radioGroup: 16;
    readonly radioButton: 17;
};
export type SemanticRole = (typeof SemanticRole)[keyof typeof SemanticRole];
export declare const SemanticState: {
    readonly None: 0;
    readonly Expanded: number;
    readonly Selected: number;
    readonly Toggled: number;
    readonly Required: number;
    readonly Disabled: number;
    readonly Focused: number;
    readonly Hidden: number;
    readonly LiveRegion: number;
    readonly ReadOnly: number;
    readonly Modal: number;
    readonly Obscured: number;
    readonly Multiline: number;
};
export declare function hasState(flags: number, state: number): boolean;
export declare const SemanticCheckState: {
    readonly Unchecked: 0;
    readonly Checked: 1;
    readonly Mixed: 2;
};
export type SemanticCheckState = (typeof SemanticCheckState)[keyof typeof SemanticCheckState];
/** Bit offset of the check field within stateFlags. */
export declare const CHECK_STATE_OFFSET = 2;
/** Mask of the check field within stateFlags. */
export declare const CHECK_STATE_MASK: number;
/**
 * Decodes the check field out of `flags`. The field is two bits. Returns 0, 1, or 2
 * per the mapping in SemanticCheckState.
 */
export declare function checkStateOf(flags: number): SemanticCheckState;
/**
 * Controls when the instance builds semantic trees and accessibility overlays.
 *
 * - `disabled`: no semantics work.
 * - `enabled`: semantics and overlay are active immediately after load.
 */
export declare const SemanticMode: {
    readonly Disabled: "disabled";
    readonly Enabled: "enabled";
};
export type SemanticMode = (typeof SemanticMode)[keyof typeof SemanticMode];
export interface RiveSemanticsOptions {
    /**
     * aria-label for the semantic DOM container element
     */
    riveCanvasLabel?: string;
}
export declare const SemanticTrait: {
    readonly None: 0;
    readonly Expandable: number;
    readonly Selectable: number;
    readonly Checkable: number;
    readonly Toggleable: number;
    readonly Requirable: number;
    readonly Enablable: number;
    readonly Focusable: number;
};
export declare function hasTrait(flags: number, trait: number): boolean;
export declare const SemanticActionType: {
    readonly tap: 0;
    readonly increase: 1;
    readonly decrease: 2;
};
export type SemanticActionType = (typeof SemanticActionType)[keyof typeof SemanticActionType];
export interface SemanticNodeData {
    readonly id: number;
    parentId: number;
    role: number;
    label: string;
    value: string;
    hint: string;
    stateFlags: number;
    traitFlags: number;
    headingLevel: number;
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
    children: number[];
}
export declare function roleName(role: number): string;
export declare function stateNames(flags: number): string;
export declare function traitNames(flags: number): string;
