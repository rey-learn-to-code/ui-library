import type {
  ImageWrapper,
  AudioWrapper,
  FontWrapper,
} from "./utils/finalizationRegistry";

interface RiveOptions {
  locateFile(file: string): string;
  wasmBinary?: ArrayBuffer;
}

declare function Rive(options?: RiveOptions): Promise<RiveCanvas>;
export default Rive;

/**
 * RiveCanvas is the main export object that contains references to different Rive classes to help
 * build the Rive render loop for low-level API usage. In addition, this contains multiple methods
 * that help aid in setup, such as loading in a Rive file, creating the renderer, and
 * starting/finishing the render loop (requestAnimationFrame)
 */
export interface RiveCanvas {
  Alignment: AlignmentFactory;
  CanvasRenderer: typeof CanvasRenderer;
  LinearAnimationInstance: typeof LinearAnimationInstance;
  StateMachineInstance: typeof StateMachineInstance;
  CustomFileAssetLoader: typeof CustomFileAssetLoader;
  Mat2D: typeof Mat2D;
  Vec2D: typeof Vec2D;
  AABB: AABB;
  SMIInput: typeof SMIInput;
  renderFactory: CanvasRenderFactory;

  BlendMode: typeof BlendMode;
  FillRule: typeof FillRule;
  Fit: typeof Fit;
  RenderPaintStyle: typeof RenderPaintStyle;
  StrokeCap: typeof StrokeCap;
  StrokeJoin: typeof StrokeJoin;
  decodeAudio: DecodeAudio;
  decodeImage: DecodeImage;
  decodeFont: DecodeFont;
  // Returns a pointer value to the FontWrapper
  setFallbackFontCallback: (callback: (missingGlyph: number, fallbackFontIndex: number, weight: number) => number | null) => void;

  /**
   * @experimental Creates a deferred recording session. Only present in builds
   * with deferred rendering compiled in, so always feature-detect it.
   *
   * The session is a Factory: pass it to `load()` and to the decode APIs of the
   * assets that belong to that file, and attach it to exactly one renderer with
   * `attachSession()`.
   *
   * Teardown order should be:
   *   1. release the file the session imported,
   *   2. `detachSession()` on the renderer it is attached to,
   *   3. `delete()` the session.
   * Deleting an attached session leaves the renderer pointing at freed memory
   * on the canvas2d build — the next frame either draws from freed heap or
   * throws `Cannot pass deleted object`. Detach first, always, even when the
   * renderer is about to be deleted too.
   *
   * @returns A DeferredSession, or undefined if the session could not be created
   */
  makeDeferredSession?(): DeferredSession | undefined;

  /**
   * Loads a Rive file for the runtime and returns a Rive-specific File class
   *
   * @param buffer - Array buffer of a Rive file
   * @param assetLoader - FileAssetLoader used to optionally customize loading of font and image assets
   * @param enableRiveAssetCDN - boolean flag to allow loading assets from the Rive CDN, enabled by default.
   * @param session - @experimental Deferred session to import through. The file's mode is fixed
   * at import: pass null (the default) for an immediate file.
   * @returns A Promise for a Rive File class
   */
  load(
    buffer: Uint8Array,
    assetLoader?: FileAssetLoader,
    enableRiveAssetCDN?: boolean,
    session?: DeferredSession | null,
  ): Promise<File>;

  /**
   * Creates the renderer to draw the Rive on the provided canvas element
   *
   * @param canvas - Canvas to draw the Rive on
   * @param useOffscreenRenderer - Option for those using the WebGL-variant of the Rive JS library.
   * This uses an offscreen renderer to draw on the canvas, allowing for multiple Rives/canvases on
   * a given screen. It is highly recommended to set this to `true` when using with the
   * `@rive-app/webgl` package
   * @returns A Rive CanvasRenderer (Canvas2D) or Renderer (WebGL) class
   */
  makeRenderer(
    canvas: HTMLCanvasElement | OffscreenCanvas,
    useOffscreenRenderer?: boolean,
  ): WrappedRenderer;

  /**
   * Computes how the Rive is laid out onto the canvas
   * @param {Fit} fit - Fit enum (i.e Fit.contain)
   * @param alignment - Alignment enum (i.e Alignment.center)
   * @param frame - AABB object representing the bounds of the canvas frame
   * @param content - AABB object representing the bounds of what to draw the Rive onto
   * (i.e an artboard's size)
   * @param scaleFactor - Scale factor of the artboard when using `Fit.layout`
   * @returns Mat2D - A Mat2D view matrix
   */
  computeAlignment(
    fit: Fit,
    alignment: Alignment,
    frame: AABB,
    content: AABB,
    scaleFactor?: number,
  ): Mat2D;

  mapXY(matrix: Mat2D, canvasPoints: Vec2D): Vec2D;
  /**
   * A Rive-specific requestAnimationFrame function; this must be used instead of the global
   * requestAnimationFrame function.
   * @param cb - Callback function to call with an elapsed timestamp
   * @returns number - An ID of the requestAnimationFrame request
   */
  requestAnimationFrame(cb: (timestamp: DOMHighResTimeStamp) => void): number;
  /**
   * A Rive-specific cancelAnimationFrame function; this must be used instead of the global
   * cancelAnimationFrame function.
   * @param requestID - ID of the requestAnimationFrame request to cancel
   */
  cancelAnimationFrame(requestID: number): void;
  /**
   * A Rive-specific function to "flush" queued up draw calls from using the renderer.
   *
   * This should only be invoked once at the end of a loop in a regular JS
   * requestAnimationFrame loop, and should not be used with the Rive-wrapped
   * requestAnimationFrame (aka, the requestAnimationFrame() API on this object) as that
   * API will handle flushing the draw calls implicitly.
   */
  resolveAnimationFrame(): void;
  /**
   * Debugging tool to showcase the FPS in the corner of the screen in a new div. If a callback
   * function is provided, this function passes the FPS count to the callback instead of creating a
   * new div so the client can decide what to do with that data.
   */
  enableFPSCounter(cb?: (fps: number) => void): void;
  /**
   * Debugging tool to remove the FPS counter that displays from enableFPSCounter
   */
  disableFPSCounter(): void;

  /**
   * Cleans up any WASM-generate objects that need to be destroyed manually.
   * This should be called when you wish to remove a rive animation from view.
   */
  cleanup(): void;

  /**
   * Returns whether or not there are Rive Listeners configured on a given StateMachineInstance
   * @param stateMachine - StateMachineInstance to check for Listeners
   * @returns bool - Boolean of if there are Listners on the state machine
   */
  hasListeners(stateMachine: StateMachineInstance): boolean;
}

//////////////
// RENDERER //
//////////////

/**
 * @experimental A deferred recording session, owned by the RiveFile that imported
 * through it.
 *
 * A session records for one ore/GL context, so it binds to exactly one renderer
 * and can never rebind once detached. It must outlive the file it imported.
 */
export declare class DeferredSession {
  delete(): void;
  /**
   * @experimental Whether anything was recorded into this session's stream this
   * frame, including ore content the artboard's own change flag cannot see.
   * Only meaningful before the renderer clears: clear opens a recording window
   * that marks the stream, so a later read reports every frame as recorded.
   */
  recordedThisFrame(): boolean;
}

/**
 * Rive wrapper around a rendering context for a canvas element, implementing a subset of the APIs
 * from the rendering context interface
 */
export declare class RendererWrapper {
  /**
   * Saves the state of the canvas and pushes it onto a stack
   *
   * For the underlying API, check
   * https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D/save
   */
  save(): void;
  /**
   * Restores the most recent state of the canvas saved on the stack
   *
   * For the underlying API, check
   * https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D/restore
   */
  restore(): void;
  transform(tranform: Mat2D): void;
  drawPath(path: RenderPath, paint: RenderPaint): void;
  clipPath(path: RenderPath): void;
  /**
   * Begins a frame. Crucial to call this at the start of the render loop: besides clearing
   * the canvas, it registers the renderer so that its queued draws actually get flushed.
   *
   * Pass clear=false to draw on top of whatever the canvas already holds instead of
   * starting from a blank one.
   *
   * For the underlying clear, check
   * https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D/clearRect
   */
  beginFrame(clear?: boolean): void;
  /**
   * @deprecated Use {@link beginFrame} instead. Equivalent to `beginFrame(true)`.
   */
  clear(): void;
  delete(): void;
  flush(): void;
  translate(x: number, y: number): void;
  rotate(angle: number): void;
  /**
   * (WebGL only) Makes the GL context that backs this renderer's textures current, before
   * performing any WASM teardown that frees resources
   */
  bindContext?(): void;
  /**
   * @experimental Binds a deferred session to this renderer's context: draws record
   * into the session and replay at flush. Absent on renderers that cannot replay a
   * session (an offscreen renderer, or a build without deferred support).
   *
   * @param session - The session the file was imported through
   * @returns false if this renderer already has a session, or the session is (or was)
   * bound elsewhere. Attaching is once per session: re-import into a fresh session instead
   */
  attachSession?(session: DeferredSession): boolean;
  /**
   * @experimental Releases the attached session's replay state. The session can never
   * be attached again.
   */
  detachSession?(): void;
  /**
   * @experimental Whether a deferred session is currently attached.
   */
  deferredActive?(): boolean;
}

export declare class RenderPathWrapper {
  reset(): void;
  addPath(
    path: CommandPath,
    xx: number,
    xy: number,
    yx: number,
    yy: number,
    tx: number,
    ty: number,
  ): void;
  fillRule(value: FillRule): void;
  moveTo(x: number, y: number): void;
  lineTo(x: number, y: number): void;
  cubicTo(
    ox: number,
    oy: number,
    ix: number,
    iy: number,
    x: number,
    y: number,
  ): void;
  close(): void;
}

export declare class RenderPaintWrapper {
  color(value: number): void;
  thickness(value: number): void;
  join(value: StrokeJoin): void;
  cap(value: StrokeCap): void;
  blendMode(value: BlendMode): void;
  style(value: RenderPaintStyle): void;
  linearGradient(sx: number, sy: number, ex: number, ey: number): void;
  radialGradient(sx: number, sy: number, ex: number, ey: number): void;
  addStop(color: number, stop: number): void;
  completeGradient(): void;
  gradientTransform(
    xx: number,
    xy: number,
    yx: number,
    yy: number,
    tx: number,
    ty: number,
  ): void;
}

/**
 * Renderer returned when Rive makes a renderer via `makeRenderer()`
 */
export declare class Renderer extends RendererWrapper {
  /**
   * Aligns the Rive content on the canvas space
   * @param fit - Fit enum value
   * @param alignment - Alignment enum value
   * @param frame - Bounds of the canvas space
   * @param content - Bounds of the Rive content
   * @param _scaleFactor - Scale factor of the artboard when using `Fit.layout`
   */
  align(
    fit: Fit,
    alignment: Alignment,
    frame: AABB,
    content: AABB,
    scaleFactor?: number,
  ): void;
}

export declare class CommandPath { }

export declare class RenderPath extends RenderPathWrapper { }

export declare class RenderPaint extends RenderPaintWrapper { }

/////////////////////
// CANVAS RENDERER //
/////////////////////
export declare class CanvasRenderer extends Renderer {
  constructor(
    ctx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D,
  );
}

type OmittedCanvasRenderingContext2DMethods =
  | "createConicGradient"
  | "createImageData"
  | "createLinearGradient"
  | "createPattern"
  | "createRadialGradient"
  | "getContextAttributes"
  | "getImageData"
  | "getLineDash"
  | "getTransform"
  | "isContextLost"
  | "isPointInPath"
  | "isPointInStroke"
  | "measureText";

/**
 * Proxy class that handles calls to a CanvasRenderer instance and handles Rive-related rendering calls such
 * as `save`, `restore`, `transform`, and more, effectively overriding and/or wrapping Canvas2D context
 * APIs for Rive-specific purposes. Other calls not intentionally overridden are passed through to the
 * Canvas2D context directly.
 *
 * Note: Currently, any calls to the Canvas2D context that you expect to return a value (i.e. `isPointInStroke()`)
 * will return undefined
 */
export type CanvasRendererProxy = CanvasRenderer &
  Omit<CanvasRenderingContext2D, OmittedCanvasRenderingContext2DMethods>;

/**
 * Renderer type for `makeRenderer()` that returns Renderer (webgl) or a CanvasRendererProxy (canvas2d)
 */
export type WrappedRenderer = Renderer | CanvasRendererProxy;

export declare class CanvasRenderPaint extends RenderPaint {
  draw(
    ctx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D,
    path: RenderPath,
  ): void;
}

export declare class CanvasRenderPath extends RenderPath { }

export interface CanvasRenderFactory {
  makeRenderPaint(): CanvasRenderPaint;
  makeRenderPath(): CanvasRenderPath;
}

export class AudioInternal {
  unref(): void;
}
export class Audio {
  unref(): void;
  get nativeAudio(): AudioInternal;
}
export interface AudioCallback {
  (audio: Audio): void;
}
/**
 * The trailing session is the one of the deferred file the asset is bound into;
 * an asset decoded against any other factory is dropped when that file draws.
 */
export interface DecodeAudio {
  (
    bytes: Uint8Array,
    callback: AudioCallback,
    session?: DeferredSession | null,
  ): void;
}
export class ImageInternal {
  unref(): void;
}
export class Image {
  unref(): void;
  get nativeImage(): ImageInternal;
}
export interface ImageCallback {
  (image: Image): void;
}
export interface DecodeImage {
  (
    bytes: Uint8Array,
    callback: ImageCallback,
    session?: DeferredSession | null,
  ): void;
}
export class FontInternal {
  unref(): void;
  ptr(): number;
}
export class Font {
  unref(): void;
  ptr(): number;
  get nativeFont(): FontInternal;
}
export interface FontCallback {
  (font: Font): void;
}
export interface DecodeFont {
  (
    bytes: Uint8Array,
    callback: FontCallback,
    session?: DeferredSession | null,
  ): void;
}

//////////
// File //
//////////
/**
 * Rive-specific File class that provides a number of functions to load instances of Artboards
 */
export declare class File {
  /**
   * Returns the first Artboard found in the Rive file as a new Artboard instance
   * @returns An Artboard instance
   */
  defaultArtboard(): Artboard; // rive::ArtboardInstance
  /**
   * Returns the named Artboard found in the Rive file as a new Artboard instance
   * @param name - Name of the Artboard to create an instance for
   */
  artboardByName(name: string): Artboard; // rive::ArtboardInstance
  /**
   * Returns a new Artboard instance for the Artboard at the given index in the Rive file
   * @param index - Index of the Artboard in the file to create an Artboard instance for
   */
  artboardByIndex(index: number): Artboard; // rive::ArtboardInstance
  /**
   * Returns the number of Artboards in the Rive File
   * @returns Number of artboards in the Rive file
   */
  artboardCount(): number;
  /**
   * Returns the number of View Models in the Rive File
   * @returns Number of view models in the Rive file
   */
  viewModelCount(): number;
  /**
   * Reports device pixels per layout point to scripts in this file
   * @param scale - Device pixels per layout point
   */
  displayScale(scale: number): void;
  /**
   * Returns a view model by the index in which it is located in the file
   * @returns ViewModel
   */
  viewModelByIndex(index: number): ViewModel;
  /**
   * Returns a view model by name
   * @returns ViewModel
   */
  viewModelByName(name: string): ViewModel;

  /**
   * Returns the default view model for the provided artboard
   * @returns ViewModel
   */
  defaultArtboardViewModel(artboard: Artboard): ViewModel;

  /**
   * Returns a list of all data enums
   * @returns DataEnum array in the Rive file
   */
  enums(): DataEnum[];

  /**
   * Returns the names of the file's global view models, in file order.
   * @returns array of global view model names
   */
  globalViewModelNames(): string[];

  unref(): void;

  /**
   * Returns a reference to a bindable artboard from this file by name
   * @returns BindableArtboard
   */
  bindableArtboardByName(name: string): BindableArtboard;

  /**
   * Returns a reference to the default bindable artboard
   * @returns BindableArtboard
   */
  bindableArtboardDefault(): BindableArtboard;

  /**
   * Returns a reference to a bindable artboard. FOR INTERNAL USE ONLY
   * @param artboard - Name of the Artboard to create an instance for
   * @returns BindableArtboard
   */
  internalBindableArtboardFromArtboard(artboard: Artboard): BindableArtboard;

  /**
   * If the file has an audio asset, returns true
   */
  get hasAudio(): boolean;
}

/**
 * Rive class representing an Artboard instance. Use this class to create instances for
 * LinearAnimations, StateMachines, Nodes, Bones, and more. This Artboard instance should also be
 * advanced in the drawing render loop.
 *
 * Important: Make sure to delete this instance when it's no longer in use via the `delete()`
 * method. This deletes the underlying c++ reference and frees up the backing WASM object. This can
 * be done in cases where the user navigates away from the page with this animation, the canvas is
 * unmounted, etc.
 */
export declare class Artboard {
  /**
   * Get the name of this Artboard instance
   */
  get name(): string;
  /**
   * Get the bounds of this Artboard instance
   */
  get bounds(): AABB;
  get hasAudio(): boolean;
  get frameOrigin(): boolean;
  set frameOrigin(val: boolean);
  /**
   * Getter and setter for the artboard volume
   */
  get volume(): number;
  set volume(val: number);

  /**
   * Getter and setter for the artboard width
   */
  get artboardWidth(): number;
  set artboardWidth(val: number);

  /**
   * Getter and setter for the artboard height
   */
  get artboardHeight(): number;
  set artboardHeight(val: number);

  /**
   * Getter and setter used in rendering and canvas/artboard resizing
   */
  get devicePixelRatioUsed(): number;
  set devicePixelRatioUsed(val: number);

  /**
   * Reset the artboard size to its original values
   */
  resetArtboardSize(): void;
  /**
   * Deletes the underlying instance created via the WASM. It's important to clean up this
   * instance when no longer in use
   */
  delete(): void;
  /**
   * Advances the Artboard instance by the set amount of seconds. This method updates each object
   * in the Artboard with any changes that animations apply on properties of the objects. This
   * should be called after calling `advance()` of a LinearAnimationInstance or StateMachineInstance
   * @param sec - Scrub the Artboard instance by a number of seconds
   */
  advance(sec: number): boolean;
  /**
   * Draws the artboard with a given rendering context.
   * @param renderer - Renderer context to draw with
   */
  draw(renderer: CanvasRenderer | Renderer): void;
  /**
   * Creates a LinearAnimation for the animation with the given name
   *
   * Note: This does not create a LinearAnimationInstance to advance in the render loop.
   * That needs to be created separately.
   *
   * @param name - Name of the animation to create a LinearAnimation reference for
   * @returns A new LinearAnimation object
   */
  animationByName(name: string): LinearAnimation;
  /**
   * Creates a LinearAnimation for the animation with the given index
   *
   * Note: This does not create a LinearAnimationInstance to advance in the render loop.
   * That needs to be created separately.
   *
   * @param index - Index of the animation to create a LinearAnimation reference for
   * @returns A new LinearAnimation object
   */
  animationByIndex(index: number): LinearAnimation;
  /**
   * Returns the number of animations in the artboard
   * @returns Number of animations on the Artboard
   */
  animationCount(): number;
  /**
   * Creates a StateMachine for the state machine with the given name.
   *
   * Note: This does not create a StateMachineInstance to advance in the render loop.
   * That needs to be created separately.
   *
   * @param name - Name of the state machine to create a StateMachine reference for
   * @returns A new StateMachine object
   */
  stateMachineByName(name: string): StateMachine;
  /**
   * Creates a StateMachine for the state machine with the given index
   *
   * Note: This does not create a StateMachineInstance to advance in the render loop.
   * That needs to be created separately.
   *
   * @param index - Index of the state machine to create a StateMachine reference for
   * @returns A new StateMachine object
   */
  stateMachineByIndex(index: number): StateMachine;
  /**
   * Returns the number of state machines in the artboard
   * @returns Number of state machines on the Artboard
   */
  stateMachineCount(): number;
  /**
   * Returns a reference for a Bone object of a given name.
   * Learn more: https://rive.app/community/doc/bones/docYyQwxrgI5
   *
   * @param name - Name of the Bone to grab a reference to
   */
  bone(name: string): Bone;
  /**
   * Returns a reference for a Node object of a given name from the Artboard hierarchy
   * @param name - Name of the Node from the Artboard hierarchy to grab a reference to
   */
  node(name: string): Node;
  /**
   * Returns a reference for a root Bone object of a given name
   * @param name - Name of the root Bone to grab a reference to
   */
  rootBone(name: string): RootBone;
  /**
   * Returns a reference for a transform component object of a given name
   * @param name - Name of the transform component to grab a reference to
   */
  transformComponent(name: string): TransformComponent;
  /**
   * Returns a reference for a TextValueRun object to get/set a text value for
   * @param name - Name of the Text Run to grab a reference to
   */
  textRun(name: string): TextValueRun;
  /**
   * Returns a reference for a SMIInput object to get/set an input value for
   * @param name - Name of the Input to grab a reference to
   * @param path - Path of where the input exists at an artboard level
   */
  inputByPath(name: string, path: string): SMIInput;
  /**
   * Returns a reference for a TextValueRun object to get/set a text value for
   * @param name - Name of the Text Run to grab a reference to
   * @param path - Path of where the text exists at an artboard level
   */
  textByPath(name: string, path: string): TextValueRun;
  /**
   * Getter and setter for the artboard width
   */
  get width(): number;
  set width(val: number);
  /**
   * Getter and setter for the artboard height
   */
  get height(): number;
  set height(val: number);
  /**
   * Reset the artboard size to the original value
   */
  resetArtboardSize(): void;
  /**
   * binds the view model instance to the artboard
   * @param instance - Renderer context to draw with
   */
  bindViewModelInstance(instance: ViewModelInstance): void;
  /**
   * Sets the main view model instance without rebinding. Call bind() to apply.
   */
  setViewModelInstance(instance: ViewModelInstance): void;
  /**
   * Applies the current data context (rebinds data binds). No-op if nothing set.
   */
  bind(): void;
  /**
   * Sets/replaces the global view model instance bound under the given global
   * view model name without rebinding, preserving the main instance and the
   * other globals' order. Call bind() to apply.
   * @returns false if the name does not match a global view model in the file.
   */
  setGlobalViewModelInstance(name: string, instance: ViewModelInstance): boolean;
  /**
   * @returns the global view model instance currently bound under the given
   * name (the runtime-seeded default or a previously set instance), or null if
   * the name does not match a global view model in the file.
   */
  globalViewModelInstance(name: string): ViewModelInstance | null;

  didChange(): boolean;
}

export declare class BindableArtboard {
  unref(): void;
}

export declare class Bone extends TransformComponent {
  /**
   * Length of the bone
   */
  length: number;
}

export declare class RootBone extends Bone {
  /**
   * X coordinate of the position on the RootBone
   */
  x: number;
  /**
   * Y coordinate of the position on the RootBone
   */
  y: number;
}

/**
 * Representation of a node in the Artboard hierarchy (i.e group, shape, etc.)
 */
export declare class Node extends TransformComponent {
  /**
   * X coordinate of the position on the Node
   */
  x: number;
  /**
   * Y coordinate of the position on the RootBone
   */
  y: number;
}

export declare class TransformComponent {
  rotation: number;
  scaleX: number;
  scaleY: number;
  worldTransform(): Mat2D;
  parentWorldTransform(result: Mat2D): void;
}

///////////////
// Animation //
///////////////
/**
 * Rive class representing a LinearAnimation instance. Use this class to advance and control a
 * particular animation in the render loop (i.e speed, scrub, mix, etc.).
 *
 * Important: Make sure to delete this instance when it's no longer in use via the `delete()`
 * method. This deletes the underlying c++ reference and frees up the backing WASM object. This can
 * be done in cases where the user navigates away from the page with this animation, the canvas is
 * unmounted, etc.
 */
export declare class LinearAnimationInstance {
  /**
   * Create a new LinearAnimationInstance reference
   * @param animation - A LinearAnimation reference retrieved via the Artboard
   * (i.e `artboard.animationByName('foo')`)
   * @param artboard - The Artboard instance for this animation
   */
  constructor(animation: LinearAnimation, artboard: Artboard);
  get name(): string;
  get duration(): number;
  get fps(): number;
  get workStart(): number;
  get workEnd(): number;
  get loopValue(): number;
  get speed(): number;
  /**
   * Number of seconds the animation has advanced by
   */
  time: number;
  /**
   * Flag to determine if the animation looped (this is reset when the loop restarts)
   */
  didLoop: boolean;
  /**
   * Advances/scrubs the LinearAnimationInstance by the set amount of seconds. Note that this only
   * moves the "time" in the animation, but does not apply changes to the properties in the
   * Artboard. This must be called before the `apply()` method of LinearAnimationInstance.
   *
   * @param sec - Scrub the animation instance by a number of seconds
   */
  advance(sec: number): boolean;
  /**
   * Apply a mixing value on the animation instance. This is useful if you are looking to blend
   * multiple animations together and want to dictate a strength for each of the animations played
   * back. This also applies new values to properties of objects on the Artboard according to the
   * keys of the animation.
   * This must be called after the `advance()` method of `LinearAnimationInstance`
   *
   * @param mix 0-1 the strength of the animation in the animations mix.
   */
  apply(mix: number): void;
  /**
   * Deletes the underlying instance created via the WASM. It's important to clean up this instance
   * when no longer in use
   */
  delete(): void;
}

export declare class TextValueRun {
  /**
   * Getter for the name of the Text Run
   */
  get name(): string;
  /**
   * Getter for text value of the Text Run
   */
  get text(): string;
  /**
   * Setter for the text value of the Text Run
   */
  set text(val: string);
}

/**
 * Rive Event interface for "General" custom events defined in the Rive editor. Each event has a
 * name and optionally some other custom properties and a type
 */
export interface RiveEvent {
  /**
   * Name of the event fired
   */
  name: string;
  /**
   * Optional type of the specific kind of event fired (i.e. General, OpenUrl)
   */
  type?: number;
  /**
   * Optional custom properties defined on the event
   */
  properties?: RiveEventCustomProperties;
  /**
   * Optional elapsed time since the event specifically occurred
   */
  delay?: number;
}

/**
 * A specific Rive Event type for "OpenUrl" events. This event type has a URL and optionally a
 * target property to dictate how to open the URL
 */
export interface OpenUrlEvent extends RiveEvent {
  /**
   * URL to open when the event is invoked
   */
  url: string;
  /**
   * Where to display the linked URL
   */
  target?: string;
}

/**
 * A Rive Event may have any number of optional custom properties defined on itself with variable names
 * and values that are either a number, boolean, or string
 */
export interface RiveEventCustomProperties {
  /**
   * Custom property may be named anything in the Rive editor, and given a value of
   * a number, boolean, or string type
   */
  [key: string]: number | boolean | string;
}

/**
 * Snapshot of the focus state returned by StateMachineInstance.focusState().
 * Poll this each frame after advanceAndApply() to detect focus changes and
 * determine whether a virtual keyboard should be shown or hidden.
 */
export interface FocusState {
  /** True if any element currently holds focus in this state machine's active focus manager. */
  hasFocus: boolean;
  /** True if the focused element accepts keyboard input (e.g. a TextInput node). */
  expectsKeyboardInput: boolean;
}

export declare class LinearAnimation {
  /**
   * The animation's loop type
   */
  get loopValue(): number;
  /**
   * Name of the LinearAnimation
   */
  get name(): string;
}

export declare class StateMachine {
  /**
   * Name of the StateMachine
   */
  get name(): string;
}

/**
 * Rive class representing a StateMachine instance. Use this class to advance and control a
 * particular state machine in the render loop (i.e scrub, grab state machine inputs, set up
 * listener events, etc.).
 *
 * Important: Make sure to delete this instance when it's no longer in use via the `delete()`
 * method. This deletes the underlying c++ reference and frees up the backing WASM object. This can
 * be done in cases where the user navigates away from the page with this animation, the canvas is
 * unmounted, etc.
 */
export declare class StateMachineInstance {
  /**
   * Create a new StateMachineInstance reference
   * @param stateMachine - A StateMachine retrieved via the Artboard
   * (i.e `artboard.stateMachineByName('foo')`)
   * @param artboard - The Artboard instance for this state machine
   */
  constructor(stateMachine: StateMachine, artboard: Artboard);
  get name(): string;
  /**
   * Returns the number of inputs associated with this state machine
   * @returns Number of inputs
   */
  inputCount(): number;
  /**
   * Returns the state machine input at the given index
   * @param i - Index to retrieve the state machine input at
   * @returns SMIInput reference
   */
  input(i: number): SMIInput;
  /**
   * Advances/scrubs the StateMachineInstance by the set amount of seconds. Note that this does not
   * apply changes to the properties of objects in the Artboard yet.
   * @param sec - Scrub the state machine instance by a number of seconds
   */
  advance(sec: number): boolean;
  /**
   * Advances/scrubs the StateMachineInstance by the set amount of seconds. Note that this will
   * apply changes to the properties of objects in the Artboard.
   * @param sec - Scrub the state machine instance by a number of seconds
   */
  advanceAndApply(sec: number): boolean;
  /**
   * Returns the number of states changed while the state machine played
   * @returns Number of states changed in the duration of the state machine played
   */
  stateChangedCount(): number;
  /**
   * Returns the name of the state/animation transitioned to, given the index in the array of state
   * changes in total
   * @param i
   * @returns Name of the state/animation transitioned to
   */
  stateChangedNameByIndex(i: number): string;

  /**
   * Returns the number of events reported from the last advance call
   * @returns Number of events reported
   */
  reportedEventCount(): number;

  /**
   * Returns a RiveEvent object emitted from the last advance call at the given index
   * of a list of potentially multiple events. If an event at the index is not found,
   * undefined is returned.
   * @param i index of the event reported in a list of potentially multiple events
   * @returns RiveEvent or extended RiveEvent object returned, or undefined
   */
  reportedEventAt(i: number): OpenUrlEvent | RiveEvent | undefined;

  /**
   * Notifies the state machine that the pointer has pressed down at the given coordinate in
   * Artboard space. Internally, Rive may advance a state machine if the listener coordinate is of
   * interest at a given moment.
   *
   * @param x - X coordinate
   * @param y - Y coordinate
   */
  pointerDown(x: number, y: number, id: number): void;
  /**
   * Notifies the state machine that the pointer has moved to the given coordinate in
   * Artboard space. Internally, Rive may advance a state machine if the listener coordinate is of
   * interest at a given moment.
   *
   * @param x - X coordinate
   * @param y - Y coordinate
   */
  pointerMove(x: number, y: number, id: number): void;
  /**
   * Notifies the state machine that the pointer has released at the given coordinate in
   * Artboard space. Internally, Rive may advance a state machine if the listener coordinate is of
   * interest at a given moment.
   * @param x - X coordinate
   * @param y - Y coordinate
   */
  pointerUp(x: number, y: number, id: number): void;
  /**
   * Notifies the state machine that the pointer has exited the detectable area of the canvas surface
   *
   * @param x - X coordinate
   * @param y - Y coordinate
   */
  pointerExit(x: number, y: number, id: number): void;
  /**
   * Notifies the state machine of indirect scroll input (a mouse wheel, or a trackpad gesture the
   * platform already classified as a scroll) at the given coordinate in Artboard space. Direct
   * touch scrolling stays on the pointer path.
   *
   * A gesture latches to the scroll view that takes its first event and stays there, even past
   * that view's edge, until the gesture ends. A gesture with no end phase (a wheel) ends once the
   * state machine advances 0.1s without another scroll event.
   *
   * @param x - X coordinate
   * @param y - Y coordinate
   * @param dx - Horizontal distance the content moves, in Artboard pixels. Revealing content to
   * the right is negative, so a DOM wheel delta must be negated.
   * @param dy - Vertical distance the content moves, in Artboard pixels. Revealing content below
   * is negative.
   * @param phase - Where the event sits within its gesture: 0 begin, 1 update, 2 end,
   * 3 momentum, 4 inertiaCancel. A phaseless wheel only ever sends 1 (update).
   * @param precise - True for a pixel-precise source such as a trackpad, false for a detented
   * wheel.
   * @param timeStamp - Event time in seconds.
   * @param id - Pointer id
   * @returns 0 when nothing took the event, 1 when a scroll view did, 2 when an opaque scroll
   * view did.
   */
  pointerScroll(
    x: number,
    y: number,
    dx: number,
    dy: number,
    phase: number,
    precise: boolean,
    timeStamp: number,
    id: number,
  ): number;
  /**
   * Returns true if anything under the given Artboard coordinate would move for this scroll
   * event, without applying it. Always true while a gesture is latched.
   * See {@link pointerScroll} for the parameters.
   */
  wantsScroll(
    x: number,
    y: number,
    dx: number,
    dy: number,
    phase: number,
    precise: boolean,
  ): boolean;
  /**
   * Returns true if a wheel-enabled scroll view sits under the given Artboard coordinate, even
   * one that cannot move right now.
   *
   * @param x - X coordinate
   * @param y - Y coordinate
   */
  hasScrollTargetAt(x: number, y: number): boolean;
  /**
   * Returns true while a scroll gesture is latched to a scroll view in this state machine or a
   * nested one.
   */
  hasScrollLatch(): boolean;
  /**
   * Ends any scroll gesture in flight, latch included.
   */
  cancelScroll(): void;

  /**
   * Returns true if this state machine has any focus nodes registered in its focus tree.
   * Since the focus tree is unified across nested artboards, this covers the full scene.
   * Use this to gate whether tab/focus traversal DOM listeners should be attached.
   */
  hasFocusNodes(): boolean;

  /**
   * Move focus to the next focusable node in the focus tree via the state machine's focus manager.
   */
  focusNext(): boolean;

  /**
   * Move focus to the previous focusable node in the focus tree via the state machine's focus manager.
   */
  focusPrevious(): boolean;

  /**
   * Move focus to the nearest focusable node to the left of the current focus, by on-screen position.
   * @returns false if nothing is focused or no node lies in that direction
   */
  focusLeft(): boolean;

  /**
   * Move focus to the nearest focusable node to the right of the current focus, by on-screen position.
   * @returns false if nothing is focused or no node lies in that direction
   */
  focusRight(): boolean;

  /**
   * Move focus to the nearest focusable node above the current focus, by on-screen position.
   * @returns false if nothing is focused or no node lies in that direction
   */
  focusUp(): boolean;

  /**
   * Move focus to the nearest focusable node below the current focus, by on-screen position.
   * @returns false if nothing is focused or no node lies in that direction
   */
  focusDown(): boolean;

  /**
   * Clear focus from the Rive focus tree.
   */
  clearFocus(): void;

  /**
   * Returns metadata about current focus state:
   *   1. Whether any node in the focus tree is currently focused
   *   2. Whether the currently focused node expects keyboard input (i.e. keyboard/text input listener)
   */
  focusState(): FocusState;

  /**
   * Forward a key press/release to the focus tree via the state machine's focus manager.
   * The event bubbles from the primary focus node up its ancestors until a handler consumes it.
   * Modifier keys are sent as keys too; held modifiers also go in the `modifiers` bitmask.
   * @param key - GLFW-style key code (see js/src/utils/keyMap.ts)
   * @param modifiers - KeyModifiers bitmask (shift=1, ctrl=2, alt=4, meta=8)
   * @param isPressed - true for keydown, false for keyup
   * @param isRepeat - true if this is an auto-repeat keydown
   * @returns true if a node in the focus chain consumed the event
   */
  keyInput(key: number, modifiers: number, isPressed: boolean, isRepeat: boolean): boolean;

  /**
   * Forward committed text (a printable stroke, IME composition result, or paste) to the focus
   * tree. This is the only way characters get inserted into a focused text field; `keyInput`
   * never inserts text. For a printable stroke, hosts typically call both: `keyInput` so
   * keyboard listeners on that key fire, then `textInput` for the characters.
   * @param text - the committed text
   * @returns true if a node in the focus chain consumed the text
   */
  textInput(text: string): boolean;

  /**
   * The selected text of the focused element, or an empty string when nothing with a
   * selection is focused. Used to fill the clipboard on copy/cut. An obscured field 
   * (i.e. a password) reports empty string.
   */
  selectedText(): string;

  /**
   * Deletes the underlying instance created via the WASM. It's important to clean up this instance
   * when no longer in use
   */
  delete(): void;

  /**
   * binds the view model instance to the state machine
   * @param instance - Renderer context to draw with
   */
  bindViewModelInstance(instance: ViewModelInstance): void;
  /**
   * Sets the main view model instance without rebinding. Call bind() to apply.
   */
  setViewModelInstance(instance: ViewModelInstance): void;
  /**
   * Applies the current data context (rebinds data binds). No-op if nothing set.
   */
  bind(): void;
  /**
   * Sets/replaces the global view model instance bound under the given global
   * view model name without rebinding, preserving the main instance and the
   * other globals' order. Call bind() to apply.
   * @returns false if the name does not match a global view model in the file.
   */
  setGlobalViewModelInstance(name: string, instance: ViewModelInstance): boolean;
  /**
   * @returns the global view model instance currently bound under the given
   * name (the runtime-seeded default or a previously set instance), or null if
   * the name does not match a global view model in the file.
   */
  globalViewModelInstance(name: string): ViewModelInstance | null;

  /**
   * Enables semantic tree tracking for this state machine instance.
   * Once enabled, the runtime builds and maintains a semantic tree that
   * describes the accessible structure of the artboard (roles, labels,
   * states, bounds). Call this before using drainSemanticsDiff().
   */
  enableSemantics(): void;

  /**
   * Returns the incremental semantic diff since the last call, or null if
   * nothing changed. Each diff contains arrays of added/removed/moved nodes,
   * updated semantic properties, updated geometry, and children reorderings.
   */
  drainSemanticsDiff(): SemanticsDiff | null;

  /**
   * Fire a semantic action on the node with the given ID.
   * @param nodeId - The semantic node ID to target
   * @param actionType - 0 = tap, 1 = increase, 2 = decrease
   */
  fireSemanticAction(nodeId: number, actionType: number): void;

  /**
   * Request focus on the semantic node with the given ID.
   * Routes through SemanticManager to focus the FocusData sibling of the
   * SemanticData that owns the node. Returns true if focus was set.
   * @param nodeId - The semantic node ID to focus
   * @returns boolean - True if focus was set, false otherwise
   */
  focusSemanticNode(nodeId: number): boolean;

  /**
   * Clears focus from the currently focused node in the focus tree.
   */
  clearFocus(): void;
}

export interface SemanticsDiffNode {
  id: number;
  role: number;
  label: string;
  value: string;
  hint: string;
  stateFlags: number;
  traitFlags: number;
  headingLevel: number;
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
  parentId: number;
  siblingIndex: number;
}

export interface SemanticsBoundsUpdate {
  id: number;
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

export interface SemanticsChildrenUpdate {
  parentId: number;
  childIds: number[];
}

export interface SemanticsDiff {
  frameNumber: number;
  treeVersion: number;
  rootId: number;
  removed: number[];
  added: SemanticsDiffNode[];
  moved: SemanticsDiffNode[];
  childrenUpdated: SemanticsChildrenUpdate[];
  updatedSemantic: SemanticsDiffNode[];
  updatedGeometry: SemanticsBoundsUpdate[];
}

export declare class SMIInput {
  // TODO: Keep only the base SMIInput properties and make SMIBool, SMINumber, SMITriger extend it
  static bool: number;
  static number: number;
  static trigger: number;

  /**
   * Getter for name of the state machine input
   */
  get name(): string;
  get type(): number;
  /**
   * Getter for value of the state machine input
   */
  get value(): boolean | number | undefined;
  /**
   * Setter for value of the state machine input
   */
  set value(val: boolean | number | undefined);
  /**
   * Fires a trigger input on a state machine
   */
  fire(): void;
  asBool(): SMIInput;
  asNumber(): SMIInput;
  asTrigger(): SMIInput;
}

export declare type ViewModelProperty = {
  name: string;
  type: DataType;
  enumName?: string;
};

export declare class ViewModelInstanceValue {
  get hasChanged(): boolean;
  clearChanges(): void;
  get name(): string;
}

export declare class ViewModelInstanceNumber extends ViewModelInstanceValue {
  get value(): number;
  set value(val: number);
}

export declare class ViewModelInstanceTrigger extends ViewModelInstanceValue {
  trigger(): void;
}

export declare class ViewModelInstanceString extends ViewModelInstanceValue {
  get value(): string;
  set value(val: string);
}

export declare class ViewModelInstanceBoolean extends ViewModelInstanceValue {
  get value(): boolean;
  set value(val: boolean);
}

export declare class ViewModelInstanceColor extends ViewModelInstanceValue {
  get value(): number;
  set value(val: number);
  rgb(r: number, g: number, b: number): void;
  argb(a: number, r: number, g: number, b: number): void;
  alpha(a: number): void;
}

export declare class ViewModelInstanceEnum extends ViewModelInstanceValue {
  get value(): string;
  set value(val: string);
  get valueIndex(): number;
  set valueIndex(val: number);
  get values(): string[];
}

export declare class ViewModelInstanceList extends ViewModelInstanceValue {
  get size(): number;
  addInstance(vmi: ViewModelInstance): void;
  addInstanceAt(vmi: ViewModelInstance, index: number): boolean;
  removeInstance(vmi: ViewModelInstance): void;
  removeInstanceAt(index: number): void;
  instanceAt(index: number): ViewModelInstance;
  swap(a: number, b: number): ViewModelInstance;
}
export declare class ViewModelInstanceAssetImage extends ViewModelInstanceValue {
  value(image: ImageInternal | null): void;
}
export declare class ViewModelInstanceAssetFont extends ViewModelInstanceValue {
  value(font: FontInternal | null): void;
}
export declare class ViewModelInstanceArtboard extends ViewModelInstanceValue {
  value(artboard: BindableArtboard | Artboard): void;
  viewModelInstance(viewModelInstance: ViewModelInstance): void;
}

export declare class ViewModelInstance {
  get propertyCount(): number;
  number(path: string): ViewModelInstanceNumber;
  string(path: string): ViewModelInstanceString;
  boolean(path: string): ViewModelInstanceBoolean;
  color(path: string): ViewModelInstanceColor;
  enum(path: string): ViewModelInstanceEnum;
  trigger(path: string): ViewModelInstanceTrigger;
  list(path: string): ViewModelInstanceList;
  viewModel(path: string): ViewModelInstance;
  image(path: string): ViewModelInstanceAssetImage;
  font(path: string): ViewModelInstanceAssetFont;
  artboard(path: string): ViewModelInstanceArtboard;
  replaceViewModel(path: string, value: ViewModelInstance): boolean;
  incrementReferenceCount(): void;
  decrementReferenceCount(): void;
  delete(): void;
  unref(): void;
  getProperties(): ViewModelProperty[];
  getViewModelName(): string;
}

export declare class ViewModel {
  get instanceCount(): number;
  instanceByIndex(index: number): ViewModelInstance;
  instanceByName(name: string): ViewModelInstance;
  defaultInstance(): ViewModelInstance;
  instance(): ViewModelInstance;
  getProperties(): ViewModelProperty[];
  getInstanceNames(): string[];
  get propertyCount(): number;
  get name(): string;
}

export declare class DataEnum {
  get name(): string;
  get values(): string[];
}

export declare class SMIBool { }

export declare class SMINumber { }

export declare class SMITrigger { }

///////////
// ENUMS //
///////////

export enum DataType {
  none = 'none',
  string = 'string',
  number = 'number',
  boolean = 'boolean',
  color = 'color',
  list = 'list',
  enumType = 'enumType',
  trigger = 'trigger',
  viewModel = 'viewModel',
  integer = 'integer',
  listIndex = 'listIndex',
  image = 'image',
  artboard = 'artboard',
}

export enum Fit {
  fill,
  contain,
  cover,
  fitWidth,
  fitHeight,
  none,
  scaleDown,
  layout,
}

export enum RenderPaintStyle {
  fill,
  stroke,
}

export enum FillRule {
  nonZero,
  evenOdd,
}

export enum StrokeCap {
  butt,
  round,
  square,
}
export enum StrokeJoin {
  miter,
  round,
  bevel,
}

export enum BlendMode {
  srcOver = 3,
  additive = 12,
  screen = 14,
  overlay = 15,
  darken = 16,
  lighten = 17,
  colorDodge = 18,
  colorBurn = 19,
  hardLight = 20,
  softLight = 21,
  difference = 22,
  exclusion = 23,
  multiply = 24,
  hue = 25,
  saturation = 26,
  color = 27,
  luminosity = 28,
}

///////////
// UTILS //
///////////

export declare class Alignment {
  get x(): number;
  get y(): number;
}

export declare class AlignmentFactory {
  get topLeft(): Alignment;
  get topCenter(): Alignment;
  get topRight(): Alignment;
  get centerLeft(): Alignment;
  get center(): Alignment;
  get centerRight(): Alignment;
  get bottomLeft(): Alignment;
  get bottomCenter(): Alignment;
  get bottomRight(): Alignment;
}

/**
 * Axis-aligned bounding box
 */
export interface AABB {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

/**
 * Column-major matrix described by the following:
 *  | xx  yx  tx |
 *  | xy  yy  ty |
 *  |  0   0   1 |
 */
export declare class Mat2D {
  xx: number;
  xy: number;
  yx: number;
  yy: number;
  tx: number;
  ty: number;
  /**
   * Returns whether or not a matrix could be inverted, and if yes, sets the resulting Mat2D into
   * the passed-in `mat` parameter
   *
   * @param mat - Reference Mat2D to store the newly inverted matrix into if successful
   * @returns True if the matrix could be inverted
   */
  invert(mat: Mat2D): boolean;

  /**
   * Deletes the underlying CPP object created for this instance
   */
  delete(): void;
}

/**
 * Rive Vector class
 */
export declare class Vec2D {
  constructor(x: number, y: number);
  /**
   * Returns the x coordinate of the vector
   */
  x(): number;
  /**
   * Returns the y coordinate of the vector
   */
  y(): number;

  /**
   * Deletes the underlying CPP object created for this instance
   */
  delete(): void;
}

/**
 * Rive class representing a FileAsset with relevant metadata fields to describe
 * an asset associated wtih the Rive File
 */
export declare class FileAsset {
  name: string;
  fileExtension: string;
  uniqueFilename: string;
  isAudio: boolean;
  isImage: boolean;
  isFont: boolean;
  cdnUuid: string;

  /**
   * @param session - @experimental The session of the deferred file this asset belongs
   * to, null for an immediate file. Wired by the runtime; pass it explicitly only when
   * calling the native asset directly.
   */
  decode(bytes: Uint8Array, session?: DeferredSession | null): void;
  get nativeAsset(): FileAssetInternal;
}

/**
 * Rive class representing a FileAsset with relevant metadata fields to describe
 * an asset associated wtih the Rive File
 */
export declare class FileAssetInternal {
  name: string;
  fileExtension: string;
  uniqueFilename: string;
  isAudio: boolean;
  isImage: boolean;
  isFont: boolean;
  cdnUuid: string;

  decode(bytes: Uint8Array, session?: DeferredSession | null): void;
}

export declare class AudioAssetInternal extends FileAssetInternal {
  setAudioSource(audio: AudioInternal): void;
}

/**
 * Rive class extending the FileAsset that exposes a `setAudioSource()` API with a
 * decoded Audio (via the `decodeAudio()` API) to set a new Audio on the Rive FileAsset
 */
export declare class AudioAsset extends FileAsset {
  setAudioSource(audio: Audio | AudioWrapper): void;
}

export declare class ImageAssetInternal extends FileAssetInternal {
  setRenderImage(image: ImageInternal): void;
}
/**
 * Rive class extending the FileAsset that exposes a `setRenderImage()` API with a
 * decoded Image (via the `decodeImage()` API) to set a new Image on the Rive FileAsset
 */
export declare class ImageAsset extends FileAsset {
  setRenderImage(image: Image | ImageWrapper): void;
}

export declare class FontAssetInternal extends FileAssetInternal {
  setFont(font: FontInternal): void;
}
/**
 * Rive class extending the FileAsset that exposes a `setFont()` API with a
 * decoded Font (via the `decodeFont()` API) to set a new Font on the Rive FileAsset
 */
export declare class FontAsset extends FileAsset {
  // Accepts the high-level `FontWrapper` returned by `decodeFont()` as well as
  // the low-level embind `Font`. `FontWrapper` lacks the `ptr()` member that was
  // added to `Font`
  setFont(font: Font | FontWrapper): void;
}

export declare class FileAssetLoader { }

export declare class CustomFileAssetLoader extends FileAssetLoader {
  constructor({ loadContents }: { loadContents: Function });
  loadContents(asset: FileAsset, bytes: any): boolean;
}

export interface FinalizableTarget {
  selfUnref: boolean;
}
