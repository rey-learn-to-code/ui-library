/**
 * Canvas offset within its offsetParent, minus the scroll of ancestors in between (they
 * move the canvas, not absolutely positioned siblings).
 */
export declare function canvasOffset(canvas: HTMLElement): {
    top: number;
    left: number;
};
