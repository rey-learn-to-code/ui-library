import * as rc from "../rive_advanced.mjs";
interface Finalizable {
    unref: () => void;
}
declare class FileFinalizer implements Finalizable {
    private _file;
    private _session;
    selfUnref: boolean;
    constructor(file: rc.File, session?: rc.DeferredSession | null);
    unref(): void;
    release(): void;
}
declare class AssetWrapper implements rc.FinalizableTarget {
    selfUnref: boolean;
    unref(): void;
}
declare class ImageWrapper extends AssetWrapper {
    private _nativeImage;
    constructor(image: rc.Image);
    get nativeImage(): rc.ImageInternal;
    unref(): void;
}
declare class AudioWrapper extends AssetWrapper {
    private _nativeAudio;
    constructor(audio: rc.Audio);
    get nativeAudio(): rc.AudioInternal;
    unref(): void;
}
declare class FontWrapper extends AssetWrapper {
    private _nativeFont;
    constructor(font: rc.Font);
    get nativeFont(): rc.FontInternal;
    unref(): void;
}
export type AssetLoadCallbackWrapper = (asset: rc.FileAssetInternal, bytes: Uint8Array) => Boolean;
declare class CustomFileAssetLoaderWrapper {
    assetLoader: rc.CustomFileAssetLoader;
    _assetLoaderCallback: AssetLoadCallbackWrapper;
    _session: rc.DeferredSession | null;
    constructor(runtime: rc.RiveCanvas, loaderCallback: AssetLoadCallbackWrapper, session?: rc.DeferredSession | null);
    loadContents(asset: rc.FileAsset, bytes: any): false | Boolean;
}
/**
 * Rive class representing a FileAsset with relevant metadata fields to describe
 * an asset associated wtih the Rive File
 */
declare class FileAssetWrapper {
    _nativeFileAsset: rc.FileAssetInternal;
    _session: rc.DeferredSession | null;
    constructor(nativeAsset: rc.FileAssetInternal, session?: rc.DeferredSession | null);
    decode(bytes: Uint8Array): void;
    get name(): string;
    get fileExtension(): string;
    get uniqueFilename(): string;
    get isAudio(): boolean;
    get isImage(): boolean;
    get isFont(): boolean;
    get cdnUuid(): string;
    get nativeFileAsset(): rc.FileAssetInternal;
}
/**
 * Rive class extending the FileAsset that exposes a `setRenderImage()` API with a
 * decoded Image (via the `decodeImage()` API) to set a new Image on the Rive FileAsset
 */
declare class ImageAssetWrapper extends FileAssetWrapper {
    setRenderImage(image: ImageWrapper): void;
}
/**
 * Rive class extending the FileAsset that exposes a `setAudioSource()` API with a
 * decoded Audio (via the `decodeAudio()` API) to set a new Audio on the Rive FileAsset
 */
declare class AudioAssetWrapper extends FileAssetWrapper {
    setAudioSource(audio: AudioWrapper): void;
}
/**
 * Rive class extending the FileAsset that exposes a `setFont()` API with a
 * decoded Font (via the `decodeFont()` API) to set a new Font on the Rive FileAsset
 */
declare class FontAssetWrapper extends FileAssetWrapper {
    setFont(font: FontWrapper): void;
}
declare const FinalizationRegistry: {
    new (fn: Function): typeof FinalizationRegistry;
    register<T extends rc.FinalizableTarget>(object: T, description: Finalizable): void;
    unregister<T>(object: T): void;
};
declare class FakeFinalizationRegistry {
    constructor(_: Function);
    register(object: rc.FinalizableTarget): void;
    unregister<T>(_: T): void;
}
declare const finalizationRegistry: {
    new (fn: Function): typeof FinalizationRegistry;
    register<T extends rc.FinalizableTarget>(object: T, description: Finalizable): void;
    unregister<T>(object: T): void;
} | FakeFinalizationRegistry;
declare const createFinalization: <T extends Finalizable>(target: rc.FinalizableTarget, finalizable: T) => void;
export { finalizationRegistry, createFinalization, Finalizable, ImageWrapper, AudioWrapper, FontWrapper, ImageAssetWrapper, AudioAssetWrapper, FontAssetWrapper, CustomFileAssetLoaderWrapper, FileAssetWrapper, FileFinalizer, };
