export interface TextInputProxyParams {
    /** Where to mount the proxy — the canvas's parent so it scrolls/positions with it. */
    container: HTMLElement;
    /** The Rive canvas, used to position the proxy over it (iOS scroll-jump avoidance) and for domain checks. */
    canvas: HTMLElement;
    /** Forward committed text (typing, IME/dead-key commits, paste) into the focus tree. */
    textInput: (text: string) => boolean;
    /** Physical key events on the proxy route back through KeyboardInteractions' shared policy. */
    onKeyDown: (event: KeyboardEvent) => void;
    onKeyUp: (event: KeyboardEvent) => void;
    /** The field is empty; fill the clipboard from Rive's selection. */
    onCopy: (event: ClipboardEvent) => void;
    /** Called when the proxy loses DOM focus; the receiver decides whether to tear the session down. */
    onBlur: (relatedTarget: EventTarget | null) => void;
}
/**
 * Invisible per-instance <input> capturing IME/dead-key/paste text; focusable inside a
 * gesture to raise mobile keyboards. Always empty: C++ owns value and caret. Decorated
 * for AT only while it holds DOM focus.
 */
export declare class TextInputProxy {
    private params;
    private element;
    private composing;
    private decoratedKeys;
    private lastLeft;
    private lastTop;
    constructor(params: TextInputProxyParams);
    private listeners;
    private createElement;
    private positionOverCanvas;
    /** Re-sync before input: the canvas may have scrolled since the session began. */
    private reposition;
    private onCompositionStart;
    private onCompositionEnd;
    private onInput;
    /**
     * Forward the field's text to Rive and clear it.
     *
     * TODO: iOS won't autorepeat Backspace in an empty field (needs a text mirror).
     * */
    private commit;
    private onPaste;
    private onBlur;
    /** Clear any transient value and decoration. Does not blur the element. */
    endSession(): void;
    /** Must be called synchronously inside a gesture on iOS to raise the keyboard. */
    focus(): void;
    hasDomFocus(): boolean;
    owns(target: EventTarget | null): boolean;
    /** See EditingHost.decorate. */
    decorate(attrs: Record<string, string | null>): void;
    /**
     * type=password for obscured fields so AT doesn't echo keys.
     * TODO: source "type" from Core, not semantics.
     */
    setSecure(secure: boolean): void;
    /** Drop all decoration and return to the AT-invisible baseline. */
    resetDecoration(): void;
    cleanup(): void;
}
